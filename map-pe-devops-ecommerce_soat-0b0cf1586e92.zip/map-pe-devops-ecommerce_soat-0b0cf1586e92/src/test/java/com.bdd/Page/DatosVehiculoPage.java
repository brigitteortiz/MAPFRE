package com.bdd.Page;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.Select;

import java.util.Arrays;
import java.util.List;
import java.util.Random;

public class DatosVehiculoPage extends PageObject {


    // LOCATOR DATOS VEHICULO
    private By listMarca = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlMarca\"]");
    private By listModelo = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlModelo\"]");
    private By txtYearFabr = By.xpath("//*[@id=\"ContentPlaceHolder1_txtAnho\"]");
    private By listClase = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlCategoria\"]");
    private By listNumAsientos = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlNumAsientos\"]");
    private By listUsoVehiculo = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlUso\"]");
    private By btnMejorPrecio = By.xpath("//*[@id=\"ContentPlaceHolder1_btnComprar\"  or @type='submit']");

    private WebDriver driver;
    private BasePage basePage;
    public DatosVehiculoPage(WebDriver driver) {
        this.driver = driver;
    }

    //INGRESAR DATOS DEL VEHICULO
    public void datosVehiculo(String marca, String modelo, String clase, String yearFabric, String numAsientos, String usoVehiculo) {
        try {
            basePage.waitVisible(listMarca);
            basePage.selectValue(listMarca,marca);
            basePage.selectValue(listModelo, modelo);
            basePage.sendKey(txtYearFabr,yearFabric);
            basePage.selectValue(listClase, clase);
            basePage.selectValue(listNumAsientos, numAsientos);

            if (!clase.equals("MOTOCICLETA")){
                basePage.selectValue(listUsoVehiculo, "Particular");
                basePage.selectValue(listUsoVehiculo, "Otros");
                basePage.selectValue(listUsoVehiculo, "Taxi");
                basePage.selectValue(listUsoVehiculo, usoVehiculo);
                System.out.println("SUS: Los Datos del Vihiculo son Correcto");
            } else {
                basePage.selectValue(listUsoVehiculo, "Particular");
                basePage.selectValue(listUsoVehiculo, "Comercial");
                basePage.selectValue(listUsoVehiculo, usoVehiculo);
                System.out.println("SUS: Los Datos del Vihiculo son Correcto");
            }
        }catch (Exception e){
            System.err.println("FAIL: Error Los Datos del Vihiculo" + e);
            Assert.assertTrue(false);
        }
    }


    //INGRESAR DATOS DEL VEHICULO TOYOTA - YARIS
    public void datosVehiculoToyota(String yearFabric) {
        try {
            basePage.waitVisible(listMarca);
            basePage.selectValue(listMarca,"TOYOTA");
            basePage.selectValue(listModelo, "YARIS");
            basePage.sendKey(txtYearFabr,yearFabric);
            basePage.selectValue(listClase, "AUTOMOVIL");
            basePage.selectValue(listNumAsientos, "5");
            basePage.selectValue(listUsoVehiculo, "Otros");
            basePage.selectValue(listUsoVehiculo, "Particular");
            basePage.selectValue(listUsoVehiculo, "Taxi");
            System.out.println("SUS: Los Datos del Vihiculo son Correcto");

        }catch (Exception e){
            System.err.println("FAIL: Error Los Datos del Vihiculo" + e);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONAR EL BOTON VER MEJOR PRECIO
    public void obtenElMejorPrecio() {
        try {
            basePage.click(btnMejorPrecio);
            System.out.println("SUS: El boton: Obtener el mejor precio (Datos Del Vehiculo) es Correcto ");
        }catch (Exception e){
            System.err.println("Error El boton Obtener el mejor precio (Datos Del Vehiculo)  " + e);
            Assert.assertTrue(false);
        }
    }

}
