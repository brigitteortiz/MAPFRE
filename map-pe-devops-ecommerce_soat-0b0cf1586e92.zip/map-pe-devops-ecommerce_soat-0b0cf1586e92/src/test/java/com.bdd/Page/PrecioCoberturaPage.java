package com.bdd.Page;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.sql.SQLOutput;

public class PrecioCoberturaPage extends PageObject {


    // LOCATOR FECH. INICIO DE COBERTURA SOAT
    private By textEligeLaFechaDeInicioDecoberturaDeTuSoat = By.xpath("//*[contains(text(),'Elige la fecha de inicio de cobertura de tu SOAT')]");
    private By textEsteEsElMejorPrecio = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/div[1]/div/h3");
    private By getPrecioSoat = By.xpath("//*[@id=\"ContentPlaceHolder1_lblCotizacion\"]");
    private By getInicioVigencia = By.xpath("//*[@id=\"datepicker\"]");
    private By getFinVigencia = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/div[1]/div/div[3]/div/div[2]/span[3]");
    private By btnCalendario = By.xpath("//*[@type='button' and @class='Zebra_DatePicker_Icon Zebra_DatePicker_Icon_Inside']");
    private By btnContinuar = By.xpath("//*[@id=\"ContentPlaceHolder1_btnComprar\"]");

    private By textResumenMarca = By.xpath("//*[(@id='ContentPlaceHolder1_ucResumenCompraWeb_lblMarca')]");
    private By textResumenModelo = By.xpath("//*[(@id='ContentPlaceHolder1_ucResumenCompraWeb_lblModelo')]");
    private By textResumenAnho = By.xpath("//*[(@id='ContentPlaceHolder1_ucResumenCompraWeb_lblAnho')]");
    private By textResumenCategoria = By.xpath("//*[(@id='ContentPlaceHolder1_ucResumenCompraWeb_lblCategoria')]");
    private By textResumenUso = By.xpath("//*[(@id='ContentPlaceHolder1_ucResumenCompraWeb_lblUso')]");
    private By textResumeAsientos = By.xpath("//*[(@id='ContentPlaceHolder1_ucResumenCompraWeb_lblNumAsientos')]");


    private WebDriver driver;
    private BasePage basePage;

    public PrecioCoberturaPage(WebDriver driver) {
        this.driver = driver;
    }

    //VALIDAR PRECIO Y VIGENCIA DE SOAT PARTICULAR, Y RESUMEN QUE SE MUESTRA CON LOS DATOS CARGADOS DEL VIHICULO
    public void validarPrecioyVigenciaSoat() throws Exception {
        basePage.waitVisible(textEligeLaFechaDeInicioDecoberturaDeTuSoat);
        try {
            //VALIDAR PARA LOS TIPO PARTICULAR
            if (driver.findElement(textEsteEsElMejorPrecio).getText().equals("Este es el mejor precio para tu HYUNDAI VENUE")) {
                Assert.assertEquals("Este es el mejor precio para tu HYUNDAI VENUE", basePage.getText(textEsteEsElMejorPrecio));
                String getPreSotat = basePage.getText(textEsteEsElMejorPrecio);
                System.out.println("SUS: " + getPreSotat);

      //          basePage.equals(textEsteEsElMejorPrecio, "Este es el mejor precio para tu HYUNDAI VENUE"

                if (basePage.isDisplayed(getPrecioSoat)) {
                    Assert.assertEquals("66.00", driver.findElement(getPrecioSoat).getText());
                    String getPreSotat1 = basePage.getText(getPrecioSoat);
                    System.out.println("El precio es: " + getPreSotat1);
                } else {
                    System.err.println("FAIL: En Precio y Vigencia Soat");
                    Assert.assertTrue(false);
                }


                if (basePage.isDisplayed(getInicioVigencia)) {
                    basePage.getText(getInicioVigencia);
                    basePage.getText(getFinVigencia);
                    System.out.println("SUS: Inifio y Fin de Vigencia");
                } else {
                    System.err.println("FAIL: Inicio y FIn de Vigencia ");
                    Assert.assertTrue(false);
                }

                System.out.println("Datos del Vehiculo Capturados");

                Assert.assertEquals("HYUNDAI", basePage.getText(textResumenMarca));
                String gettextResumenMarca = basePage.getText(textResumenMarca);
                System.out.println("SUS: La Marca es : " + gettextResumenMarca);

                Assert.assertEquals("VENUE", basePage.getText(textResumenModelo));
                String gettextResumenModelo = basePage.getText(textResumenModelo);
                System.out.println("SUS: El Modelo es : " + gettextResumenModelo);

                Assert.assertEquals("2020", basePage.getText(textResumenAnho));
                String gettextResumenAnho = basePage.getText(textResumenAnho);
                System.out.println("SUS: EL Año de Fabricacion es: " + gettextResumenAnho);

                Assert.assertEquals("CAMIONETA RURAL SIMPLE TRACC", basePage.getText(textResumenCategoria));
                String gettextResumenCategoria = basePage.getText(textResumenCategoria);
                System.out.println("SUS: La Categoria es : " + gettextResumenCategoria);

                Assert.assertEquals("PARTICULAR", basePage.getText(textResumenUso));
                String gettextResumenUso = basePage.getText(textResumenUso);
                System.out.println("SUS: Uso de Vehiculo : " + gettextResumenUso);

                Assert.assertEquals("5", basePage.getText(textResumeAsientos));
                String gettextResumeAsientos = basePage.getText(textResumeAsientos);
                System.out.println("SUS: Numero de Asiento : " + gettextResumeAsientos);


            }
            /// VALIDAR PARA LOS TIPO TAXI
            else if (basePage.equals(textEsteEsElMejorPrecio, "Este es el mejor precio para tu TOYOTA YARIS")) {
                Assert.assertEquals("Este es el mejor precio para tu TOYOTA YARIS", basePage.getText(textEsteEsElMejorPrecio));
                String gettextEsteEsElMejorPrecio = basePage.getText(textEsteEsElMejorPrecio);
                System.out.println("SUS: " + gettextEsteEsElMejorPrecio);

                if (basePage.isDisplayed(getPrecioSoat)) {
                    Assert.assertEquals("212.00", driver.findElement(getPrecioSoat).getText());
                    String getPreSoat = basePage.getText(getPrecioSoat);
                    System.out.println("El precio del Soat Taxi es: " + getPreSoat);
                } else {
                    System.err.println("FAIL: En Precio y Vigencia Soat");
                    Assert.assertTrue(false);
                }


                if (basePage.isDisplayed(getInicioVigencia)) {
                    basePage.getText(getInicioVigencia);
                    basePage.getText(getFinVigencia);
                    basePage.click(btnCalendario);
                    basePage.sendKeyScape(btnCalendario);
                    System.out.println("SUS: Inifio y Fin de Vigencia");
                } else {
                    System.err.println("FAIL: Inicio y FIn de Vigencia ");
                    Assert.assertTrue(false);
                }


                if (basePage.isDisplayed(textResumenMarca)) {
                    Assert.assertEquals("TOYOTA", basePage.getText(textResumenMarca));
                    String gettextResumenMarca = basePage.getText(textResumenMarca);
                    System.out.println("SUS: La Marca es : " + gettextResumenMarca);

                    Assert.assertEquals("YARIS", basePage.getText(textResumenModelo));
                    String gettextResumenModelo = basePage.getText(textResumenModelo);
                    System.out.println("SUS: El Modelo es : " + gettextResumenModelo);

                    Assert.assertEquals("2021", basePage.getText(textResumenAnho));
                    String gettextResumenAnho = basePage.getText(textResumenAnho);
                    System.out.println("SUS: EL Año de Fabricacion es: " + gettextResumenAnho);

                    Assert.assertEquals("AUTOMOVIL", basePage.getText(textResumenCategoria));
                    String gettextResumenCategoria = basePage.getText(textResumenCategoria);
                    System.out.println("SUS: La Categoria es : " + gettextResumenCategoria);

                    Assert.assertEquals("TAXI", basePage.getText(textResumenUso));
                    String gettextResumenUso = basePage.getText(textResumenUso);
                    System.out.println("SUS: Uso de Vehiculo : " + gettextResumenUso);

                    Assert.assertEquals("5", basePage.getText(textResumeAsientos));
                    String gettextResumeAsientos = basePage.getText(textResumeAsientos);
                    System.out.println("SUS: Numero de Asiento : " + gettextResumeAsientos);
                }
            }
            //PARA LAS MOTOS PARTICULARES
            else if(basePage.equals(textEsteEsElMejorPrecio, "Este es el mejor precio para tu YAMAHA 250")){
                Assert.assertEquals("Este es el mejor precio para tu YAMAHA 250", basePage.getText(textEsteEsElMejorPrecio));
                String gettextEsteEsElMejorPrecio = basePage.getText(textEsteEsElMejorPrecio);
                System.out.println("SUS: " + gettextEsteEsElMejorPrecio);

                if (basePage.isDisplayed(getPrecioSoat)) {
                    Assert.assertEquals("550.00", basePage.getText(getPrecioSoat));
                    String getPreSoat = basePage.getText(getPrecioSoat);
                    System.out.println("El precio del Soat Taxi es: " + getPreSoat);
                } else {
                    System.err.println("FAIL: En Precio y Vigencia Soat");
                    Assert.assertTrue(false);
                }


                if (basePage.isDisplayed(getInicioVigencia)) {
                    basePage.getText(getInicioVigencia);
                    basePage.getText(getFinVigencia);
                    basePage.click(btnCalendario);
                    basePage.sendKeyScape(btnCalendario);
                    System.out.println("SUS: Inifio y Fin de Vigencia");
                } else {
                    System.err.println("FAIL: Inicio y FIn de Vigencia ");
                    Assert.assertTrue(false);
                }


                if (basePage.isDisplayed(textResumenMarca)) {
                    Assert.assertEquals("YAMAHA", basePage.getText(textResumenMarca));
                    String gettextResumenMarca = basePage.getText(textResumenMarca);
                    System.out.println("SUS: La Marca es : " + gettextResumenMarca);

                    Assert.assertEquals("250", basePage.getText(textResumenModelo));
                    String gettextResumenModelo = basePage.getText(textResumenModelo);
                    System.out.println("SUS: El Modelo es : " + gettextResumenModelo);

                    Assert.assertEquals("2021", basePage.getText(textResumenAnho));
                    String gettextResumenAnho = basePage.getText(textResumenAnho);
                    System.out.println("SUS: EL Año de Fabricacion es: " + gettextResumenAnho);

                    Assert.assertEquals("MOTOCICLETA", basePage.getText(textResumenCategoria));
                    String gettextResumenCategoria = basePage.getText(textResumenCategoria);
                    System.out.println("SUS: La Categoria es : " + gettextResumenCategoria);

                    Assert.assertEquals("PARTICULAR", basePage.getText(textResumenUso));
                    String gettextResumenUso = basePage.getText(textResumenUso);
                    System.out.println("SUS: Uso de Vehiculo : " + gettextResumenUso);

                    Assert.assertEquals("2", basePage.getText(textResumeAsientos));
                    String gettextResumeAsientos = basePage.getText(textResumeAsientos);
                    System.out.println("SUS: Numero de Asiento : " + gettextResumeAsientos);
                }
            }
        } catch (Exception e) {
            System.err.println("Error Precio y Vigencia SOTAT " + e);
            Assert.assertTrue(false);
        }
    }

//            if (basePage.isDisplayed(textEsteEsElMejorPrecio)) {
//                Assert.assertEquals("Este es el mejor precio para tu HYUNDAI VENUE",
//                        driver.findElement(textEsteEsElMejorPrecio).getText());
//                String getPreSotat = basePage.getText(textEsteEsElMejorPrecio);
//                System.out.println("SUS: " + getPreSotat);
//            } else {
//                System.err.println("FAIL: El Mensaje No es el correcto");
//                Assert.assertTrue(false);
//            }

//            if (basePage.isDisplayed(getPrecioSoat)) {
//                Assert.assertEquals("66.00", driver.findElement(getPrecioSoat).getText());
//                String getPreSotat = basePage.getText(getPrecioSoat);
//                System.out.println("El precio es: " + getPreSotat);
//            } else {
//                System.err.println("FAIL: En Precio y Vigencia Soat");
//                Assert.assertTrue(false);
//            }
//
//
//            if (basePage.isDisplayed(getInicioVigencia)) {
//                basePage.getText(getInicioVigencia);
//                basePage.getText(getFinVigencia);
//                System.out.println("SUS: Inifio y Fin de Vigencia");
//            } else {
//                System.err.println("FAIL: Inicio y FIn de Vigencia ");
//                Assert.assertTrue(false);
//            }
//
//            System.out.println("Datos del Vehiculo Capturados");
//
//            Assert.assertEquals("HYUNDAI", basePage.getText(textResumenMarca));
//            String gettextResumenMarca = basePage.getText(textResumenMarca);
//            System.out.println("SUS: La Marca es : " + gettextResumenMarca);
//
//            Assert.assertEquals("VENUE", basePage.getText(textResumenModelo));
//            String gettextResumenModelo = basePage.getText(textResumenModelo);
//            System.out.println("SUS: El Modelo es : " + gettextResumenModelo);
//
//            Assert.assertEquals("2020", basePage.getText(textResumenAnho));
//            String gettextResumenAnho = basePage.getText(textResumenAnho);
//            System.out.println("SUS: EL Año de Fabricacion es: " + gettextResumenAnho);
//
//            Assert.assertEquals("CAMIONETA RURAL SIMPLE TRACC", basePage.getText(textResumenCategoria));
//            String gettextResumenCategoria = basePage.getText(textResumenCategoria);
//            System.out.println("SUS: La Categoria es : " + gettextResumenCategoria);
//
//            Assert.assertEquals("PARTICULAR",basePage.getText(textResumenUso));
//            String gettextResumenUso = basePage.getText(textResumenUso);
//            System.out.println("SUS: Uso de Vehiculo : " + gettextResumenUso);
//
//            Assert.assertEquals("5", basePage.getText(textResumeAsientos));
//            String gettextResumeAsientos = basePage.getText(textResumeAsientos);
//            System.out.println("SUS: Numero de Asiento : " + gettextResumeAsientos);









    //VALIDAR PRECIO Y VIGENCIA DE SOAT TAXI, Y RESUMEN QUE SE MUESTRA CON LOS DATOS CARGADOS DEL VIHICULO
    public void validarPrecioyVigenciaSoatTaxi() {
        try{

            if (basePage.isDisplayed(textEsteEsElMejorPrecio)){
                Assert.assertEquals("Este es el mejor precio para tu TOYOTA YARIS",basePage.getText(textEsteEsElMejorPrecio));
                String gettextEsteEsElMejorPrecio =  basePage.getText(textEsteEsElMejorPrecio);
                System.out.println("SUS: " + gettextEsteEsElMejorPrecio);
            } else {
                System.err.println("FAIL: El Texto No es el correcto");
                Assert.assertTrue(false);
            }


            if (basePage.isDisplayed(getPrecioSoat)){
                Assert.assertEquals("212.00", driver.findElement(getPrecioSoat).getText());
                String getPreSoat =  basePage.getText(getPrecioSoat);
                System.out.println("El precio del Soat Taxi es: " + getPreSoat);
            } else {
                System.err.println("FAIL: En Precio y Vigencia Soat");
                Assert.assertTrue(false);
            }


            if (basePage.isDisplayed(getInicioVigencia)){
                basePage.getText(getInicioVigencia);
                basePage.getText(getFinVigencia);
                basePage.click(btnCalendario);
                basePage.sendKeyScape(btnCalendario);
                System.out.println("SUS: Inifio y Fin de Vigencia");
            }else {
                System.err.println("FAIL: Inicio y FIn de Vigencia ");
                Assert.assertTrue(false);
            }


            if (basePage.isDisplayed(textResumenMarca)) {
                Assert.assertEquals("TOYOTA", basePage.getText(textResumenMarca));
                String gettextResumenMarca = basePage.getText(textResumenMarca);
                System.out.println("SUS: La Marca es : " + gettextResumenMarca);

                Assert.assertEquals("YARIS",basePage.getText(textResumenModelo));
                String gettextResumenModelo = basePage.getText(textResumenModelo);
                System.out.println("SUS: El Modelo es : " + gettextResumenModelo);

                Assert.assertEquals("2021", basePage.getText(textResumenAnho));
                String gettextResumenAnho = basePage.getText(textResumenAnho);
                System.out.println("SUS: EL Año de Fabricacion es: " + gettextResumenAnho);

                Assert.assertEquals("AUTOMOVIL", basePage.getText(textResumenCategoria));
                String gettextResumenCategoria = basePage.getText(textResumenCategoria);
                System.out.println("SUS: La Categoria es : " + gettextResumenCategoria);

                Assert.assertEquals("TAXI", basePage.getText(textResumenUso));
                String gettextResumenUso = basePage.getText(textResumenUso);
                System.out.println("SUS: Uso de Vehiculo : " + gettextResumenUso);

                Assert.assertEquals("5",  basePage.getText(textResumeAsientos));
                String gettextResumeAsientos = basePage.getText(textResumeAsientos);
                System.out.println("SUS: Numero de Asiento : " + gettextResumeAsientos);

            } else {
                System.err.println("FAIL: Inicio y FIn de Vigencia ");
                Assert.assertTrue(false);
            }


        }catch (Exception e){
            System.err.println("Error Precio y Vigencia SOTAT " + e);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONAR BOTON CONTINUAR EN PRECIO Y COBERTURA
    public void Continuar() {
        try {
            if (basePage.isDisplayed(btnContinuar)){
                basePage.click(btnContinuar);
                System.out.println("SUS: Boton Continuar Correcto");
            }else {
                System.err.println("FAIL: Error en el Boton  Continuar ");
                Assert.assertTrue(false);
            }
        }catch (Exception e) {
            System.err.println("FAIL: Error en Datos Personales " + e);
            Assert.assertTrue(false);
        }
    }

}
