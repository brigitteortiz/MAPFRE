package com.bdd.StepDefinition;

import com.bdd.Step.SoatStep;
import cucumber.api.PendingException;
import cucumber.api.java.es.Cuando;
import cucumber.api.java.es.Dado;
import cucumber.api.java.es.Entonces;
import cucumber.api.java.es.Y;
import net.thucydides.core.annotations.Steps;
import net.thucydides.core.steps.ScenarioSteps;
import org.openqa.selenium.WebDriver;

import javax.jws.soap.SOAPBinding;

public class SoatStepDefinition {
    @Steps
    private SoatStep soatStep;

    //-----------------------------------------------------------------------------------------
    //----------------------  @Soat-ID 3759---PAGO VISA---------------------------------------------

    @Dado("^que el usuario ingresa al aplicativo SOAT Mapfre$")
    public void que_el_usuario_ingresa_al_aplicativo_SOAT_Mapfre() throws Exception {
        soatStep.UrlPre();
    }

    @Y("^El usuario ingresa el numero de su placa y  \"([^\"]*)\" \"([^\"]*)\"$")
    public void elUsuarioIngresaElNumeroDeSuPlacaY(String claseVehiculo, String usoVehiculo) throws Exception {
        soatStep.ingresarPlacayVehiculo(claseVehiculo,usoVehiculo);
    }


    @Y("^da click en el checbox, Acepto la clausula de protección de datos$")
    public void daClickEnElChecboxAceptoLaClausulaDeProtecciónDeDatos() {

        soatStep.seleccionarCheckBox();
    }

    @Y("^luego da click en el boton Ver Precio$")
    public void luegoDaClickEnElBotonVerPrecio() throws Exception {
        soatStep.verPrecio();
    }


    @Entonces("^el sistema muestra Datos del Vehiculo, el usuario ingresa los datos solicitados \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\"$")
    public void elSistemaMuestraDatosDelVehiculoElUsuarioIngresaLosDatosSolicitados(String marca, String modelo, String clase, String yearFabric, String numAsientos, String usoVehiculo) throws Throwable {
        soatStep.datosVehiculo(marca,modelo,clase, yearFabric, numAsientos, usoVehiculo);

    }

    @Y("^da click en el boton Obten el mejor precio$")
    public void da_click_en_el_boton_Obten_el_mejor_precio() throws Exception {
        soatStep.verMejorPrecio();
    }

    @Entonces("^el sistema muestra Precio y Vigencia, ingresar los datos solicitados por el sistema \\(Fecha Ini\\. Cob\\. Soat\\)$")
    public void el_sistema_muestra_Precio_y_Vigencia_ingresar_los_datos_solicitados_por_el_sistema_Fecha_Ini_Cob_Soat() throws Exception {
        soatStep.validarPrecioyVigenciaSoat();
    }

    @Y("^da click en el boton Continuar$")
    public void da_click_en_el_boton_Continuar() throws Exception {
        soatStep.btnContinuar();
    }

    @Entonces("^el sistema muestra Datos Personales, el usuario ingresa los datos solicitados CEX\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void elSistemaMuestraDatosPersonalesElUsuarioIngresaLosDatosSolicitadosCEX(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Throwable {
        soatStep.datosPersonalesCex(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }


    @Entonces("^ingresa el dato VN/Numero de Serie \"([^\"]*)\"$")
    public void ingresaElDatoVNNumeroDeSerie(String numserievn) throws Throwable {
        soatStep.NumSerieVN(numserievn);
    }


    @Entonces("^el sistema muestra Selecciona la forma de pago, Pago con Tarjeta o Pago con Banco$")
    public void el_sistema_muestra_Selecciona_la_forma_de_pago_Pago_con_Tarjeta_o_Pago_con_Banco() throws Exception {
        soatStep.selectFormaPago();
    }


    @Cuando("^el usuario selecciona la opcion Pago con Tarjeta$")
    public void elUsuarioSeleccionaLaOpcionPagoConTarjeta()throws Exception {
        soatStep.pagoConTarjeta();
    }


    @Y("^da click en el boton Pagar tu Soat$")
    public void da_click_en_el_boton_Pagar_tu_Soat() throws Exception {
        soatStep.btnPagarTuSoatFormaPago();
    }

    @Entonces("^se muestra una ventana solicitando los datos de la tarjeta, ingresar los datos MASTERCARD$")
    public void se_muestra_una_ventana_solicitando_los_datos_de_la_tarjeta_ingresar_los_datos_MASTERCARD() throws Exception {
        soatStep.datosDeLaTarjetaMasterCard();
    }


    @Y("^da click en el boton Pagar \\(monto\\)$")
    public void daClickEnElBotonPagarMonto() throws Exception {
        soatStep.btnPagarMontoPasarela();
    }

    @Y("^el sistema mostrara El Resumen de tu Compra satisfactoriamente \\(Particular Autos, camionetas, pickups\\)$")
    public void elSistemaMostraraElResumenDeTuCompraSatisfactoriamenteParticularAutosCamionetasPickups() throws Exception {
        soatStep.resumenCompraconTarjeta();
    }



    //-----------------------------------------------------------------------------------------
    //------------------------@Soat-ID 3760 ----PAGO BANCO CON DNI-------------------------------------

    //THE STEPS ARE EQUALS IN PAGO VISA


    @Entonces("^el sistema muestra Datos Personales, el usuario ingresa los datos solicitados DNI\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void elSistemaMuestraDatosPersonalesElUsuarioIngresaLosDatosSolicitadosDNI(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc ) throws Throwable {
        soatStep.datosPersonalesDNI(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }

    @Cuando("^el usuario selecciona la opcion PAGO BANCO$")
    public void elUsuarioSeleccionaLaOpcionPAGOBANCO() {
        soatStep.pagoBanco();
    }

    @Y("^da click en el boton Pagar en Banco$")
    public void daClickEnElBotonPagarEnBanco() throws InterruptedException {
        soatStep.btnPagarEnBanco();
    }

    @Entonces("^el sistema mostrara El Resumen de tu Compra \\(Particular\\)$")
    public void elSistemaMostraraElResumenDeTuCompraParticular() throws Throwable  {
        soatStep.resumenCompraBancoParticular();
    }


    //-----------------------------------------------------------------------------------------
    //------------------------@Soat-ID 3760 ----PAGO BANCO CON CEX -------------------------------------

    //THE STEPS ARE EQUALS IN PAGO BANCO

    @Entonces("^el sistema muestra Datos del Vehiculo, el usuario ingresa los datos solicitados \\(Marca Toyota, Modelo, Clase, \"([^\"]*)\", Num\\. Asientos, Uso Vehiculo")
    public void elSistemaMuestraDatosDelVehiculoElUsuarioIngresaLosDatosSolicitadosMarcaToyotaModeloClaseNumAsientosUsoVehiculo(String yearFabric) throws Throwable {
        soatStep.datosVehiculoToyota(yearFabric);
    }

    @Entonces("^el sistema muestra Precio y Vigencia, ingresar los datos solicitados por el sistema \\(Fecha Ini\\. Cob\\. Soat\\) del Auto Taxi$")
    public void elSistemaMuestraPrecioYVigenciaIngresarLosDatosSolicitadosPorElSistemaFechaIniCobSoatDelAutoTaxi() {
        soatStep.validarPrecioyVigenciaSoatTaxi();
    }

    @Entonces("^el sistema mostrara El Resumen de tu Compra \\(Taxi\\)$")
    public void elSistemaMostraraElResumenDeTuCompraTaxi() throws Throwable  {
        soatStep.resumenCompraBancoTaxi();
    }


    //-----------------------------------------------------------------------------------------
    //------------------------@Soat-ID 14528 ----PAGO BANCO CON RUC -------------------------------------

    //THE STEPS ARE EQUALS IN PAGO BANCO


    @Entonces("^el sistema muestra Datos Personales, el usuario ingresa los datos solicitados RUC\"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void elSistemaMuestraDatosPersonalesElUsuarioIngresaLosDatosSolicitadosRUC(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc ) throws Throwable {
        soatStep.datosPersonalesUserRuc(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }


    //-----------------------------------------------------------------------------------------
    //------------------------@Soat-ID ID3765 ----PAGO BANCO CON DNI - UTILIZANDO  MAPFRE dolares  -------------------------------------

    //THE STEPS ARE EQUALS IN PAGO BANCO


    @Entonces("^el sistema muestra Datos Personales, el usuario ingresa los datos solicitados con Dni Mapfre Dolares \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void elSistemaMuestraDatosPersonalesElUsuarioIngresaLosDatosSolicitadosConDniMapfreDolares(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Throwable {
            soatStep.datosPersonalesUserDniConMapfreDolares(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }


    @Entonces("^ingresa el dato VN/Numero de Serie \"([^\"]*)\" \\(Alfanumerico\\)$")
    public void ingresaElDatoVNNumeroDeSerieAlfanumerico(String numserievn) throws Throwable {
        soatStep.NumSerieVNAlfanumerico(numserievn);
    }

    @Entonces("^el sistema muestra Tienes MAPFRE dólares disponibles para usarlos como parte de pago$")
    public void elSistemaMuestraTienesMAPFREDólaresDisponiblesParaUsarlosComoParteDePago() {
        soatStep.muestraMapfreDolares();
    }

    @Y("^da click en el boton Utilizar mis mapfre dólares$")
    public void daClickEnElBotonUtilizarMisMapfreDólares() {
        soatStep.clickBotonUtilizarMisMapfreDolares();
    }

    @Entonces("^el sistema mostrara El Resumen de tu Compra con MapfreDolares$")
    public void elSistemaMostraraElResumenDeTuCompraConMapfreDolares() throws Exception {
        soatStep.resumenCompraConMapfreDolares();
    }

 //////////////////////////////////////////////////////////////////////////////////////////
///------------------------@Soat-ID ID3766 ----PAGO BANCO CON DNI QUE TIENE MAPFRE DOLARES, PERO SIN UTILIZAR MAPFRE DOLARES -------------------------------------

    //THE STEPS ARE EQUALS IN PAGO BANCO Y MAPFRE DOLARES

    @Y("^da click en el enlace No quiero utilizar mis MAPFRE dólares$")
    public void daClickEnElEnlaceNoQuieroUtilizarMisMAPFREDólares() {
        soatStep.ClickLinkTextNOUtilizarMisMapfreDolares();
    }


    //////////////////////////////////////////////////////////////////////////////////////////
///------------------------@Soat-ID15094  ----PAGO BANCO CON DNI PARA MOTO-----------------------------------

    //THE STEPS ARE EQUALS IN PAGO BANCO

    @Entonces("^el sistema muestra Datos Personales, el usuario ingresa los datos solicitados con Dni para Moto \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\" \"([^\"]*)\"$")
    public void elSistemaMuestraDatosPersonalesElUsuarioIngresaLosDatosSolicitadosConDniParaMoto(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Throwable {
        soatStep.datosPersonalesUserDniParaMoto(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }

    @Entonces("^el sistema mostrara El Resumen de tu Compra \\(Particular-Moto\\)$")
    public void elSistemaMostraraElResumenDeTuCompraParticularMoto() throws Exception {
        soatStep.resumenCompraParaMoto();

    }


    //////////////////////////////////////////////////////////////////////////////////////////
   ///------------------------@Soat-ID16226  ----PAGO CON TARJETA  CON DNI PARA MOTO-----------------------------------

    //THE STEPS ARE EQUALS CON TARJETA MASTERCARD

    @Entonces("^el sistema mostrara El Resumen de tu Compra \\(Comercial-Moto\\)$")
    public void elSistemaMostraraElResumenDeTuCompraComercialMoto() throws Exception {
        soatStep.resumenCompraConTarjetaParaMoto();
    }


    //////////////////////////////////////////////////////////////////////////////////////////
    ///------------------------@Soat-ID16282  ---- Formato de Placa Moto seleccionando Auto - Caso no exitoso-----------------------------------

    @Y("^El usuario ingresa \"([^\"]*)\"  \"([^\"]*)\" \"([^\"]*)\"$")
    public void elUsuarioIngresa(String numPlaca, String claseVehiculo, String usoVehiculo) throws Throwable {
        soatStep.ingresarPlacayclaseVehiculoyUsoVehiculo(numPlaca, claseVehiculo,usoVehiculo);
    }


    @Entonces("^el sistema muestra un mensaje VALIDACION 'Ingrese un formato correcto de placa'$")
    public void elSistemaMuestraUnMensajeVALIDACIONIngreseUnFormatoCorrectoDePlaca() throws Exception {
        soatStep.validarMensajeDeErrorFormatoDePlaca();
    }
}
