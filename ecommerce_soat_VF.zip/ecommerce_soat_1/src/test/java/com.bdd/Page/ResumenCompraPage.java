package com.bdd.Page;

import net.serenitybdd.core.pages.PageObject;
import org.apache.bcel.generic.ARETURN;
import org.jetbrains.annotations.Nullable;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Wait;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;
import java.util.function.Function;

public class ResumenCompraPage extends PageObject {


    //LOCATOR RESUMEN DE COMPRA BANCO
    private By textTitleResumenCompra = By.xpath("//*[contains(text(),'Resumen de tu compra')]");

    private By textGraciasPorTuCompra = By.xpath("//*[contains(text(),'¡Gracias por tu compra!')]");
    private By textAcercateATuBanco = By.xpath("//*[@id=\"ContentPlaceHolder1_lblCodTransaccion\"]");
    private By textMontoTotalAPagar = By.xpath("//*[contains(@class,'total-text')]");
    private By textResumenDatosVehiculoPagoBanco = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div");
    private By textResumenDatosContratantePagoBanco = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div");


    private By textPrecioSoatParticular = By.xpath("//span[contains(text(),'66.00')]");
    private By textPrecioSoatTaxi = By.xpath("//span[contains(text(),'212.00')]");

    //LOCATOR RESUMEN DE COMPRA CON TARJETA
    private By textFormaDePago = By.xpath("//*[contains(text(),'FORMA DE PAGO:')]");
    private By textPagoConTarjeta = By.xpath("//*[contains(text(),'Pago con Tarjeta')]");
    private By textResumenDatosDelVehiculoConTarjeta = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[1]/div/div[1]/div[2]/div");
    private By textResumenDatosDelContatanteConTarjeta = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[1]/div/div[2]/div[2]/div");
    private By textNumeroDeTarjeta = By.xpath("//*[contains(text(),'Nº DE TARJETA:')]");
    private By textDatosDeTarjetaNumerico = By.xpath("//*[@id=\"ContentPlaceHolder1_lblNumTarjeta\"]");
    private By textNumeroDeTransaccion = By.xpath("//*[contains(text(),'Nº DE TRANSACCIÓN:')]");
    private By textNumeroDeTransaccionNumerico = By.xpath("//*[@id=\"ContentPlaceHolder1_lblNumTransaccion\"]");




    private   BasePage basePage;
    private final WebDriver driver;
    public ResumenCompraPage(WebDriver driver){
        this.driver = driver;
    }



    //VALIDAR RESUMEN DE COMPRA CON  TARJETA PAGO 66 - AUTO
    public void resumenCompraConTarjeta66() throws Exception {
        basePage.waitVisible(textTitleResumenCompra);

        try {
            if (basePage.isDisplayed(textTitleResumenCompra)){
                System.out.println("SUS: Se muestra Titulo - Resumen de tu Compra");
            }

            Assert.assertEquals("¡Gracias por tu compra!",basePage.getText(textGraciasPorTuCompra));
            System.out.println("SUS: Gracias por tu Compra");

            Assert.assertEquals("Estamos procesando la emision de tu SOAT.\n" +
                            "En aproximadamente 15 minutos lo recibiras en tu correo electronico: bvsanch@mapfre.com.pe",
                    basePage.getText(textProcesandoEmisionDeTuSoat));
            String EstamosProcesandoTuSoat = basePage.getText(textProcesandoEmisionDeTuSoat);
            System.out.println("SUS: Se muestra el Texto: " + EstamosProcesandoTuSoat);


            Assert.assertEquals("¡Te enviamos la confirmación de compra!\n" +
                            "De no recibir el correo, revisa tu bandeja de SPAM o correos no deseados.",
                    basePage.getText(textTeEnviamosLaConfirmacionDeTuCompra));
            String TeEnviamosLaConfirmacionDeCompra = basePage.getText(textTeEnviamosLaConfirmacionDeTuCompra);
            System.out.println("SUS: Se muestra el texto: " + TeEnviamosLaConfirmacionDeCompra);


            int FechaDeVigenciaNumeroa = basePage.getText(textFechaVigenciaNumero).length();
            if (FechaDeVigenciaNumeroa > 0 ){
                Assert.assertEquals("FECHA DE VIGENCIA:",basePage.getText(textFechaVigencia));
                String FechaDeVigencia = basePage.getText(textFechaVigencia);
                String FechaDeVigenciaNumero = basePage.getText(textFechaVigenciaNumero);
                System.out.println("SUS: Se muestra el texto: " + FechaDeVigencia + " " + FechaDeVigenciaNumero);
            }

            Assert.assertEquals("Detalle de pago y monto total",basePage.getText(textDetalleDePagoYMonyoTotalMapfreDolares));
            String DetallePagoyMontoTotalMapfreDolares = basePage.getText(textDetalleDePagoYMonyoTotalMapfreDolares);
            System.out.println("SUS: Se muestra el texto: " + DetallePagoyMontoTotalMapfreDolares);

            Assert.assertEquals("FORMA DE PAGO:",basePage.getText(textFormaDePago));
            String FormaDePago = basePage.getText(textFormaDePago);
            Assert.assertEquals("Pago con Tarjeta", basePage.getText(textPagoConTarjeta));
            String PagoConTarjeta = basePage.getText(textPagoConTarjeta);
            Assert.assertEquals("Nº DE TARJETA:",basePage.getText(textNumeroDeTarjeta));
            String NumeroDeTarjeta = basePage.getText(textNumeroDeTarjeta);
            String NumeroDeTarjetaNumerico = basePage.getText(textDatosDeTarjetaNumerico);
            Assert.assertEquals("Nº DE TRANSACCIÓN:",basePage.getText(textNumeroDeTransaccion));
            String NumeroDeTransaccion = basePage.getText(textNumeroDeTransaccion);
            String NumeroDeTransaccionNumerico = basePage.getText(textNumeroDeTransaccionNumerico);

            System.out.println("SUS: Se muestra el texto: " + FormaDePago + "  " + PagoConTarjeta  + "  " +
                    NumeroDeTarjeta + "  " + NumeroDeTarjetaNumerico  + "  " + NumeroDeTransaccion + "  " + NumeroDeTransaccionNumerico);

            if (basePage.isDisplayed(textResumenDatosDelVehiculoConTarjeta) && basePage.isDisplayed(textResumenDatosDelContatanteConTarjeta)){
                String DatosDelVehiculo = basePage.getText(textResumenDatosDelVehiculoConTarjeta);
                String DatosDelContratante = basePage.getText(textResumenDatosDelContatanteConTarjeta);
                System.out.println("SUS: SE MUESTRAN LOS: " + DatosDelVehiculo + " " + DatosDelContratante);
                Assert.assertTrue(true);
            }else {
                System.err.println("FAIL: ERROR EN LOS ASSERT DEL RESUMEN DE COMPRA PAGO CON TARJETA");
                Assert.assertTrue(false);
            }

            Assert.assertEquals("MONTO TOTAL PAGADO: S/. 66.00",
                    driver.findElement(By.xpath("//*[contains(text(),'MONTO TOTAL PAGADO:')]")).getText());
            String MontoTotalResumen = driver.findElement(By.xpath("//*[contains(text(),'MONTO TOTAL PAGADO:')]")).getText();
            System.out.println("SUS: SE MUESTRA EL  " + MontoTotalResumen);

        }catch (Exception e){
            System.out.println("FAIL: ERROR EN EL RESUMEN DE COMPRA - PAGO CON TARJETA 66" + e);
            Assert.assertTrue(false);
        }
    }



    //VALIDAR RESUMEN DE COMPRA CON TARJETA PARA MOTO PAGO 650
    public void resumenCompraConTarjeta650() throws Exception {
        try {
            basePage.waitVisible(textTitleResumenCompra);
            System.out.println("SUS: Se muestra Titulo - Resumen de tu Compra");

            Assert.assertEquals("¡Gracias por tu compra!",basePage.getText(textGraciasPorTuCompra));
            System.out.println("SUS: Gracias por tu Compra");

            Assert.assertEquals("Estamos procesando la emision de tu SOAT.\n" +
                            "En aproximadamente 15 minutos lo recibiras en tu correo electronico: bvsanch@mapfre.com.pe",
                    basePage.getText(textProcesandoEmisionDeTuSoat));
            String EstamosProcesandoTuSoat = basePage.getText(textProcesandoEmisionDeTuSoat);
            System.out.println("SUS: Se muestra el Texto: " + EstamosProcesandoTuSoat);


            Assert.assertEquals("¡Te enviamos la confirmación de compra!\n" +
                            "De no recibir el correo, revisa tu bandeja de SPAM o correos no deseados.",
                    basePage.getText(textTeEnviamosLaConfirmacionDeTuCompra));
            String TeEnviamosLaConfirmacionDeCompra = basePage.getText(textTeEnviamosLaConfirmacionDeTuCompra);
            System.out.println("SUS: Se muestra el texto: " + TeEnviamosLaConfirmacionDeCompra);


            int FechaDeVigenciaNumeroa = basePage.getText(textFechaVigenciaNumero).length();
            if (FechaDeVigenciaNumeroa > 0 ){
                Assert.assertEquals("FECHA DE VIGENCIA:",basePage.getText(textFechaVigencia));
                String FechaDeVigencia = basePage.getText(textFechaVigencia);
                String FechaDeVigenciaNumero = basePage.getText(textFechaVigenciaNumero);
                System.out.println("SUS: Se muestra el texto: " + FechaDeVigencia + " " + FechaDeVigenciaNumero);
            }

            Assert.assertEquals("Detalle de pago y monto total",basePage.getText(textDetalleDePagoYMonyoTotalMapfreDolares));
            String DetallePagoyMontoTotalMapfreDolares = basePage.getText(textDetalleDePagoYMonyoTotalMapfreDolares);
            System.out.println("SUS: Se muestra el texto: " + DetallePagoyMontoTotalMapfreDolares);

            Assert.assertEquals("FORMA DE PAGO:",basePage.getText(textFormaDePago));
            String FormaDePago = basePage.getText(textFormaDePago);
            Assert.assertEquals("Pago con Tarjeta", basePage.getText(textPagoConTarjeta));
            String PagoConTarjeta = basePage.getText(textPagoConTarjeta);
            Assert.assertEquals("Nº DE TARJETA:",basePage.getText(textNumeroDeTarjeta));
            String NumeroDeTarjeta = basePage.getText(textNumeroDeTarjeta);
            String NumeroDeTarjetaNumerico = basePage.getText(textDatosDeTarjetaNumerico);
            Assert.assertEquals("Nº DE TRANSACCIÓN:",basePage.getText(textNumeroDeTransaccion));
            String NumeroDeTransaccion = basePage.getText(textNumeroDeTransaccion);
            String NumeroDeTransaccionNumerico = basePage.getText(textNumeroDeTransaccionNumerico);

            System.out.println("SUS: Se muestra el texto: " + FormaDePago + "  " + PagoConTarjeta  + "  " +
                    NumeroDeTarjeta + "  " + NumeroDeTarjetaNumerico  + "  " + NumeroDeTransaccion + "  " + NumeroDeTransaccionNumerico);

            if (basePage.isDisplayed(textResumenDatosDelVehiculoConTarjeta) && basePage.isDisplayed(textResumenDatosDelContatanteConTarjeta)){
                String DatosDelVehiculo = basePage.getText(textResumenDatosDelVehiculoConTarjeta);
                String DatosDelContratante = basePage.getText(textResumenDatosDelContatanteConTarjeta);
                System.out.println("SUS: SE MUESTRAN LOS: " + DatosDelVehiculo + " " + DatosDelContratante);
                Assert.assertTrue(true);
            }else {
                System.err.println("FAIL: ERROR EN LOS ASSERT DEL RESUMEN DE COMPRA PAGO CON TARJETA");
                Assert.assertTrue(false);
            }

            Assert.assertEquals("MONTO TOTAL PAGADO: S/. 650.00",
                    driver.findElement(By.xpath("//*[contains(text(),'MONTO TOTAL PAGADO:')]")).getText());
            String MontoTotalResumen = driver.findElement(By.xpath("//*[contains(text(),'MONTO TOTAL PAGADO:')]")).getText();
            System.out.println("SUS: SE MUESTRA EL  " + MontoTotalResumen);
            Assert.assertTrue(true);
        }catch (Exception e){
            System.out.println("FAIL: ERROR EN EL RESUMEN DE COMPRA - PAGO CON TARJETA 650" + e);
            Assert.assertTrue(false);
        }
    }



    //VALIDAR RESUMEN DE COMPRA CON PAGO BANCO PARTICULAR PAGO 66
    public void resumenCompraBancoPago66() throws Exception {
        basePage.waitVisible(textPrecioSoatParticular);
        System.out.println("SUS: Se muestra Titulo - Resumen de tu Compra");
        try {
                if (basePage.isDisplayed(textPrecioSoatParticular)) {
                    Assert.assertEquals("Resumen de tu compra",
                            driver.findElement(By.xpath("//*[contains(text(),'Resumen de tu compra')]")).getText());
                    System.out.println("SUS: Titulo de Resumen de Comora Correcto ");

                    Assert.assertEquals("¡Gracias por tu compra!",
                            driver.findElement(By.xpath("//*[contains(text(),'¡Gracias por tu compra!')]")).getText());
                    System.out.println("SUS: Gracias por tu Compra");

                    Assert.assertEquals("Acércate a tu banco con tu documento de identidad y pide realizar un pago a MAPFRE en soles."
                            , driver.findElement(By.xpath("//*[@id=\"ContentPlaceHolder1_lblCodTransaccion\"]")).getText());
                    System.out.println("SUS: Acércate a tu banco con tu documento de identidad y pide realizar un pago a MAPFRE en soles.");

                    Assert.assertEquals("MONTO TOTAL A PAGAR S/. 66.00",
                            driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[2]/section/div[3]/span")).getText());
                    String MontoTotalResumen = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[2]/section/div[3]/span")).getText();
                    System.out.println("SUS: SE MUESTRA EL  " + MontoTotalResumen);

                        if (driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div")).isDisplayed()
                                && driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div")).isDisplayed()) {
                            String DatosVehiculo = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div")).getText();
                            String DatosContratante = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div")).getText();
                            System.out.println("SUS: SE MUESTRAN LOS: " + DatosVehiculo + DatosContratante);
                            Assert.assertTrue(true);
                        } else {
                            System.err.println("FAIL: ERROR DE VISIBILIDAD DEL RESUMEN DE COMPRA PAGO 66");
                            Assert.assertTrue(false);
                        }

                }else {
                        System.err.println("FAIL: ERROR EN LOS ASSERT DEL RESUMEN DE COMPRA PAGO 66");
                        Assert.assertTrue(false);
                    }
        }catch (Exception e){
            System.out.println("FAIL: ERROR EN EL RESUMEN DE COMPRA - PAGO BANCO 66" + e);
            Assert.assertTrue(false);
        }
    }


    //VALIDAR RESUMEN DE COMPRA CON PAGO BANCO TAXI PAGO 212
    public void resumenCompraBancoPago212() throws Exception {
        basePage.waitVisible(textTitleResumenCompra);
        System.out.println("SUS: Se muestra Titulo - Resumen de tu Comora");

        try {

            Assert.assertEquals("Resumen de tu compra", basePage.getText(textTitleResumenCompra));
            System.out.println("SUS: Titulo de Resumen de Comora Correcto ");

            if (basePage.isDisplayed(textPrecioSoatTaxi)) {
                Assert.assertEquals("Resumen de tu compra",basePage.getText(textTitleResumenCompra));
                System.out.println("SUS: Titulo de Resumen de Comora Correcto ");


                Assert.assertEquals("¡Gracias por tu compra!",basePage.getText(textGraciasPorTuCompra));
                System.out.println("SUS: Gracias por tu Compra");

                Assert.assertEquals("Acércate a tu banco con tu documento de identidad y pide realizar un pago a MAPFRE en soles."
                        , driver.findElement(By.xpath("//*[@id=\"ContentPlaceHolder1_lblCodTransaccion\"]")).getText());
                System.out.println("SUS: Acércate a tu banco con tu documento de identidad y pide realizar un pago a MAPFRE en soles.");

                Assert.assertEquals("MONTO TOTAL A PAGAR S/. 212.00",
                        driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[2]/section/div[3]/span")).getText());
                String MontoTotalResumen = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[2]/section/div[3]/span")).getText();
                System.out.println("SUS: SE MUESTRA EL  " + MontoTotalResumen);

                if (driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div")).isDisplayed()
                        && driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div")).isDisplayed()) {
                    String DatosVehiculo = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div")).getText();
                    String DatosContratante = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div")).getText();
                    System.out.println("SUS: SE MUESTRAN LOS: " + DatosVehiculo + DatosContratante);
                    Assert.assertTrue(true);
                }
            } else {
                System.err.println("FAIL: ERROR EN LOS ASSERT DEL RESUMEN DE COMPRA PAGO 212");
                Assert.assertTrue(false);
            }
        } catch (Exception e) {
            System.out.println("FAIL: ERROR EN EL RESUMEN DE COMPRA - PAGO BANCO 212" + e);
            Assert.assertTrue(false);
        }
    }

    private By textProcesandoEmisionDeTuSoat = By.xpath("//*[contains(text(),'Estamos procesando la emision de tu SOAT.')]");
    private By textTeEnviamosLaConfirmacionDeTuCompra = By.xpath("//*[contains(text(),'¡Te enviamos la confirmación de compra!')]");
    private By textAhoraYaCuentasConTuSoatMapfre = By.xpath("//*[contains(text(),'Ahora ya cuentas con tu SOAT MAPFRE, hemos cotizado un seguro vehicular para que protejas tu ')]");
    private By textFechaVigencia = By.xpath("//*[contains(text(),'FECHA DE VIGENCIA:')]");
    private By textFechaVigenciaNumero = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/div[2]/div[2]/div[3]");


    private By textMedioDePago = By.xpath("//*[contains(text(),'MEDIO DE PAGO:')]");
    private By textMapfreDolares = By.xpath("//*[contains(text(),'MAPFRE Dólares')]");
    private By textDetalleDePagoYMonyoTotalMapfreDolares = By.xpath("//*[contains(text(),'Detalle de pago y monto total')]");

    private By textResumenDatosVehiculoMapfreDolares = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[1]/div/div[1]/div[2]/div");
    private By textResumenDatosDelContatanteMapfreDolares = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[1]/div/div[2]/div[2]/div");


    //VALIDAR RESUMEN DE COMPRA CON PAGO BANCO DNI - PAGO 0 SOLES CON MAPFREDOLARES
    public void resumenCompraConMapfreDolares() throws Exception {
        basePage.waitVisible(textTitleResumenCompra);
        System.out.println("SUS: Se muestra Titulo - Resumen de tu Comora");
        try {
                Assert.assertEquals("¡Gracias por tu compra!",basePage.getText(textGraciasPorTuCompra));
                System.out.println("SUS: Gracias por tu Compra");

            Assert.assertEquals("Estamos procesando la emision de tu SOAT.\n" +
                    "En aproximadamente 15 minutos lo recibiras en tu correo electronico: bvsanch@mapfre.com.pe",
                    basePage.getText(textProcesandoEmisionDeTuSoat));
                String EstamosProcesandoTuSoat = basePage.getText(textProcesandoEmisionDeTuSoat);
                System.out.println("SUS: Se muestra el Texto: " + EstamosProcesandoTuSoat);


            Assert.assertEquals("¡Te enviamos la confirmación de compra!\n" +
                                "De no recibir el correo, revisa tu bandeja de SPAM o correos no deseados.",
                        basePage.getText(textTeEnviamosLaConfirmacionDeTuCompra));
                String TeEnviamosLaConfirmacionDeCompra = basePage.getText(textTeEnviamosLaConfirmacionDeTuCompra);
                System.out.println("SUS: Se muestra el texto: " + TeEnviamosLaConfirmacionDeCompra);


            Assert.assertEquals("Ahora ya cuentas con tu SOAT MAPFRE, hemos cotizado un seguro vehicular para que protejas tu HYUNDAI VENUE del 2020",
                    basePage.getText(textAhoraYaCuentasConTuSoatMapfre));
            String AhoraYaCuentasConTuSoatMapfre = basePage.getText(textAhoraYaCuentasConTuSoatMapfre);
            System.out.println("SUS: Se muestra el texto: " + AhoraYaCuentasConTuSoatMapfre);


            int FechaDeVigenciaNumeroa = basePage.getText(textFechaVigenciaNumero).length();
            if (FechaDeVigenciaNumeroa > 0 ){
                Assert.assertEquals("FECHA DE VIGENCIA:",basePage.getText(textFechaVigencia));
                String FechaDeVigencia = basePage.getText(textFechaVigencia);
                String FechaDeVigenciaNumero = basePage.getText(textFechaVigenciaNumero);
                System.out.println("SUS: Se muestra el texto: " + FechaDeVigencia + " " + FechaDeVigenciaNumero);
            }

//            DateTimeFormatter dtf5 = DateTimeFormatter.ofPattern("dd/MM/yyyy");
//            System.out.println("dd/MM/yyyy-> "+dtf5.format(LocalDateTime.now()));

            Assert.assertEquals("Detalle de pago y monto total",basePage.getText(textDetalleDePagoYMonyoTotalMapfreDolares));
            String DetallePagoyMontoTotalMapfreDolares = basePage.getText(textDetalleDePagoYMonyoTotalMapfreDolares);
            System.out.println("SUS: Se muestra el texto: " + DetallePagoyMontoTotalMapfreDolares);


            Assert.assertEquals("MEDIO DE PAGO:",basePage.getText(textMedioDePago));
                String MedioDePago = basePage.getText(textMedioDePago);
            Assert.assertEquals("MAPFRE Dólares", basePage.getText(textMapfreDolares));
                String MapfreDolares = basePage.getText(textMapfreDolares);
                    System.out.println("SUS: Se muestra el texto: " + MedioDePago + "  " + MapfreDolares );


                if (basePage.isDisplayed(textResumenDatosVehiculoMapfreDolares) && basePage.isDisplayed(textResumenDatosDelContatanteMapfreDolares)){
                    String DatosDelVehiculo = basePage.getText(textResumenDatosVehiculoMapfreDolares);
                    String DatosDelContratante = basePage.getText(textResumenDatosDelContatanteMapfreDolares);
                    System.out.println("SUS: SE MUESTRAN LOS: " + DatosDelVehiculo + DatosDelContratante);
                    Assert.assertTrue(true);
                }else {
                    System.err.println("FAIL: ERROR EN LOS ASSERT DEL RESUMEN DE COMPRA PAGO CON MAPFRE DOLARES");
                    Assert.assertTrue(false);
                }
        }catch (Exception e){
            System.out.println("FAIL: ERROR EN EL RESUMEN DE COMPRA - PAGO BANCO 66" + e);
            Assert.assertTrue(false);
        }
    }


    private By textPrecioSoatParticularMoto = By.xpath("//span[contains(text(),'550.00')]");
    private By textPrecioSoatComercialMoto = By.xpath("//span[contains(text(),'650.00')]");


    //VALIDAR RESUMEN DE COMPRA CON PAGO BANCO PARA MOTO PARTICULAR PAGO 550
    public void resumenCompraBancoPago550Moto() throws Exception {
            basePage.waitVisible(textTitleResumenCompra);
            System.out.println("SUS: Se muestra Titulo - Resumen de tu Comora");
            try {
                if (basePage.isDisplayed(textPrecioSoatParticularMoto)) {
                    Assert.assertEquals("Resumen de tu compra",basePage.getText(textTitleResumenCompra));
                    System.out.println("SUS: Titulo de Resumen de Comora Correcto ");

                    Assert.assertEquals("¡Gracias por tu compra!", basePage.getText(textGraciasPorTuCompra));
                    System.out.println("SUS: Gracias por tu Compra");

                    Assert.assertEquals("Acércate a tu banco con tu documento de identidad y pide realizar un pago a MAPFRE en soles."
                            , driver.findElement(By.xpath("//*[@id=\"ContentPlaceHolder1_lblCodTransaccion\"]")).getText());
                    System.out.println("SUS: Acércate a tu banco con tu documento de identidad y pide realizar un pago a MAPFRE en soles.");

                    Assert.assertEquals("MONTO TOTAL A PAGAR S/. 550.00",
                            driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[2]/section/div[3]/span")).getText());
                    String MontoTotalResumen = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[2]/section/div[3]/span")).getText();
                    System.out.println("SUS: SE MUESTRA EL  " + MontoTotalResumen);

                    if (driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div")).isDisplayed()
                            && driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div")).isDisplayed()) {
                        String DatosVehiculo = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[1]/div[2]/div")).getText();
                        String DatosContratante = driver.findElement(By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/section[2]/section[3]/div/div[2]/div[2]/div")).getText();
                        System.out.println("SUS: SE MUESTRAN LOS: " + DatosVehiculo + DatosContratante);
                        Assert.assertTrue(true);
                    } else {
                        System.err.println("FAIL: ERROR EN LOS ASSERT DEL RESUMEN DE COMPRA PAGO 66");
                        Assert.assertTrue(false);
                    }
                }
            }catch (Exception e){
                System.out.println("FAIL: ERROR EN EL RESUMEN DE COMPRA - PAGO BANCO 66" + e);
                Assert.assertTrue(false);
            }
        }




}
