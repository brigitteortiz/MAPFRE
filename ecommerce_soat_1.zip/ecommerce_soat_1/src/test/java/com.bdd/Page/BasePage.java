package com.bdd.Page;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.*;

import java.util.concurrent.TimeUnit;

public class BasePage extends PageObject {

    private WebDriver driver;

    //Constructor inicializado
    public BasePage(WebDriver driver){
    this.driver = driver;
    }

    public void UrlPreProd() throws Exception
    {
        try
        {
            driver.get("https://soat.pre.mapfre.com.pe");
            driver.manage().window().maximize();
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo dar Acceder a la Aplicacion Soat - PreProd." );
        }
    }

    //Accion click
    public void click(By element) throws Exception
    {
        try
        {
            driver.findElement(element).click();
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo dar click sobre el elemento: " + element);
        }
    }

    public void clear(By element) throws Exception
    {
        try
        {
            driver.findElement(element).clear();
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo dar click sobre el elemento: " + element);
        }
    }


    //Accion de devolver un booleano si el elemento esta Visible
    public boolean isDisplayed(By element) throws Exception
    {
        try
        {
            return driver.findElement(element).isDisplayed();
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo devolver el valor del elemento: " + element);
        }
    }

    //Accion de devolver un boolean si el elemento esta Habilitado
    public boolean isEnabled(By element) throws Exception
    {
        try
        {
            return driver.findElement(element).isEnabled();
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo devolver el valor del elemento: " + element);
        }
    }

    //Accion obtener texto
    public String getText(By element) throws Exception
    {
        try
        {
            return driver.findElement(element).getText();
        }
        catch (Exception e)
        {
            throw new Exception("No se puedo obtener el texto del elemento: " + element);
        }
    }

    //Accion escribir caja de texto
    public void sendKey(By element, String textoCaja) throws Exception
    {
        try
        {
            driver.findElement(element).sendKeys(textoCaja);
        }
        catch (Exception e)
        {
            throw new Exception("No se escribir dentro del elemento: " + element);
        }
    }


    //Accion Tab
    public void sendKeyTab(By element) throws Exception
    {
        try
        {
            driver.findElement(element).sendKeys(Keys.TAB);
        }
        catch (Exception e)
        {
            throw new Exception("No se escribir dentro del elemento: " + element);
        }
    }


    //Accion Escape
    public void sendKeyScape(By element) throws Exception
    {
        try
        {
            driver.findElement(element).sendKeys(Keys.ESCAPE);
        }
        catch (Exception e)
        {
            throw new Exception("No Realiza el Teclado Escape: " + element);
        }
    }


    //Accion obtiene el titulo de la pagina
    public String getTitle() {

          return driver.getTitle();
    }


    //Accion de seleccion Lista - Combo Box
    public void selectValue(By element, String valor) throws Exception
    {
        try
        {
            //return driver.findElement(element).getText();
            Select se = new Select(driver.findElement(element));
            se.selectByVisibleText(valor);
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo seleccionar el elemento" + element);
        }
    }

    public WebElement selectValueGetFirst(By element) throws Exception
    {
        try
        {
            //return driver.findElement(element).getText();
            Select se = new Select(driver.findElement(element));
            return se.getFirstSelectedOption();
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo seleccionar el elemento" + element);
        }
    }

    //Esperar elemento sea Visible
    public void waitVisible(By element) throws Exception
    {
        try
        {
            WebDriverWait wait = new WebDriverWait(driver, 180);
            wait.until(ExpectedConditions.visibilityOfElementLocated(element));
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo esperar el elemento " + e);
        }
    }

    //ESPERAR QUE EL ELEMENTO SEA CLICLEABLE
    public void waitClicleable(By element) throws Exception
    {
        try
        {
            WebDriverWait wait = new WebDriverWait(driver, 35);
            wait.until(ExpectedConditions.elementToBeClickable(element));
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo esperar el elemento " + e);
        }
    }

    //ESPERA QUE LA ALERTA ESTE PRESENTE
    public void waitPresent() throws Exception
    {
        try
        {
            WebDriverWait wait = new WebDriverWait(driver, 15);
            wait.until(ExpectedConditions.alertIsPresent());
        }
        catch (Exception e)
        {
            throw new Exception("No se pudo esperar el elemento " + e);
        }
    }







    //USAR RL EQUALS PARA COMPARAR UN OBJETO CON UN TEXTO - BOOLEAN
    public boolean equals(By element, String textObjeto) throws Exception
    {
        try
        {
          return  driver.findElement(element).equals(textObjeto);

        }
        catch (Exception e)
        {
            throw new Exception("El Texto es diferente al Elemento: " + element);
        }
    }


}
