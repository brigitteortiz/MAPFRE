//import cucumber.api.CucumberOptions;
import io.cucumber.junit.CucumberOptions;
import net.serenitybdd.cucumber.CucumberWithSerenity;
import org.junit.runner.RunWith;

@RunWith(CucumberWithSerenity.class)
@CucumberOptions(
        plugin = {"pretty"},
        features = "src/test/resources/features",
        tags = "@Soat-ID3759" // Esquema del escenario: CP070_Emisión de póliza - Pago con Tarjeta (MASTERCARD) - con CEX - OK
        /*tags = "@Soat-ID3760" //Esquema del escenario: CP071_Emisión de póliza - Pago en Banco con DNI (DNI NO TIENE PARA PAGO EN BANCO)
        tags = "@Soat-14525" //Esquema del escenario: CP071_Emisión de póliza - Pago en Banco con CEX (DATA NO TIENE PARA PAGO EN BANCO)
        tags ="@Soat-14528" //Esquema del escenario: CP071_Emisión de póliza - Pago en Banco con RUC (DATA NO TIENE PARA PAGO EN BANCO)
        tags ="@Soat-ID3765" //Esquema del escenario: CP006_Realizar la emisión de SOAT Digital - Utilizando MAPFRE Dólares - Pago en Banco con DNI (DATA NO TIENE MAPFRE DOLARES - PARA PAGO EN BANCO)
        tags ="@Soat-ID3766" //Esquema del escenario: CP007_Realizar la emisión de SOAT Digital - Sin utilizar MAPFRE Dólares - Pago en Banco - Ubigeo Lima o Callao (DATA NO TIENE MAPFRE DOLARES - PARA PAGO EN BANCO)
        tags ="@Soat-ID15094" //Esquema del escenario: Validar cotización de SOAT para placa de MOTO con pago banco exitoso - Flujo original - OK
        tags ="@Soat-ID16226" //Esquema del escenario: Validar cotización de SOAT para placa de MOTO con pago tarjeta martercard - exitoso - OK
        tags ="@Soat-ID3768" //Esquema del escenario: CP009_Realizar la emisión de SOAT Digital - No Utilizando MAPFRE Dólares - Pago con Tarjeta MasterCard - Ubigeo Lima o Callao (DATA NO TIENE MAPFRE DOLARES - PARA PAGO EN BANCO)
        tags ="@Soat-ID16282" //Esquema del escenario: Validar el rechazo de placa para moto, ingresando en la seleccion de clase Autos con uso particular - Caso No Exitoso - OK
*/
)
public class RunnerTest {
}