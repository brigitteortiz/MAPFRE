package Step;

import Page.*;
import net.thucydides.core.annotations.Step;
import net.thucydides.core.steps.ScenarioSteps;
import org.jsoup.Connection;

public class SoatStep extends ScenarioSteps{

 private BasePage basePage;
 private SoatHomePage soatHomePage;
 private DatosVehiculoPage datosVehiculoPage;
 private PrecioCoberturaPage precioCoberturaPage;
 private DatosPersonalesPage datosPersonalesPage;
 private NumeroSeriePage numeroSeriePage;
 private FormaPagoPage formaPagoPage;
 private ResumenCompraPage resumenCompraPage;


 //////////////////////// PAGO  CON TARJETA  -  CEX /////////////////
 ////////////////////////////////////////////////////////////////
@Step
    public void UrlPre() throws Exception {
        System.out.println("Executenado UrlPre (1)");
        basePage.open();
        System.out.println("SUS: La Aplicacion SOAT Cargo correctamente");
    }

    public void ingresarPlacayVehiculo(String claseVehiculo, String usoVehiculo) throws Exception {
       // soatHomePage.selectComboClaseVehiculo(claseVehiculo);
        soatHomePage.selectCombUsoVehiculo(claseVehiculo,usoVehiculo);
        soatHomePage.ingresarPlaca(claseVehiculo);
    }

    public void seleccionarCheckBox() {
        soatHomePage.seleccionarCheckBox();
    }

    public void verPrecio() throws Exception {
        soatHomePage.verPrecio();
    }

    public void datosVehiculo(String marca, String modelo, String clase, String yearFabric, String numAsientos, String usoVehiculo) throws Exception{
        datosVehiculoPage.datosVehiculo(marca,modelo,clase, yearFabric, numAsientos, usoVehiculo);
    }

    public void verMejorPrecio() throws Exception {
        datosVehiculoPage.obtenElMejorPrecio();
    }

    public void validarPrecioyVigenciaSoat() throws Exception {
        precioCoberturaPage.validarPrecioyVigenciaSoat();
    }

    public void btnContinuar() {
        precioCoberturaPage.Continuar();
    }
    public void btnContinuarSoatMoto() throws Exception{
        precioCoberturaPage.ContinuarSoatMoto();

    }


    public void datosPersonalesCex(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        datosPersonalesPage.DatosPersonalesCEX(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }

    public void botonContinuarDeIngresarDatosPersonales()throws Exception{
        datosPersonalesPage.botonContinuarDeIngresarDatosPersonales();
    }

    public void btnContinuarConDatosRegistradosEnBD() {
        datosPersonalesPage.btnContinuarConDatosRegistradosEnBD();
    }
    public void NumSerieVN(String numserievn) throws Exception {
        numeroSeriePage.numserievn(numserievn);
    }
    public void botonContinuarDeVin() throws Exception{
        numeroSeriePage.botonContinuarDespuesDeIngresarVin();
    }
    public void selectFormaPago() throws Exception {
        // numeroSeriePage.isAlertPresent();
        formaPagoPage.selectFormaPago();
    }

    public void pagoConTarjeta() {
        formaPagoPage.pagoConTarjeta();
    }

    public void btnPagarTuSoatFormaPago() {
        formaPagoPage.btnPagarTuSoatFormaPago();
    }

    public void datosDeLaTarjetaMasterCard() throws Exception {
        formaPagoPage.datosDeLaTarjetaMasterCardPasarelaDePago();
    }

    public void btnPagarMontoPasarela() throws Exception {
        formaPagoPage.btnPagarMontoPasarela();
    }

    public void resumenCompraconTarjeta() throws Exception {
        resumenCompraPage.resumenCompraConTarjeta66();
    }


    //////////////////////////PAGO BANCO  CON DNI ////////////////////////
    //////////////////////////////////////////////////////////////////////

    public void datosPersonalesDNI(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception{
        datosPersonalesPage.DatosPersonalesDNI(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }

    public void pagoBanco() {
        formaPagoPage.pagoBanco();
    }

    public void btnPagarEnBanco() throws InterruptedException {
        formaPagoPage.btnPagarEnBancoFormaPago();
        Thread.sleep(8000);

    }

    public void resumenCompraBancoParticular() throws Exception {
        resumenCompraPage.resumenCompraBancoPago66();
    }


    //////////////////////////PAGO BANCO  CEX ////////////////////////
    //////////////////////////////////////////////////////////////////////

//    public void IngresaPlacaYUsoTaxi() throws InterruptedException {
//        soatHomePage.ingresarPlaca();
//        soatHomePage.selectCombUsoVehiculo();
//    }



    public void datosVehiculoToyota(String yearFabric) {
        datosVehiculoPage.datosVehiculoToyota(yearFabric);
    }

    public void validarPrecioyVigenciaSoatTaxi() {
        precioCoberturaPage.validarPrecioyVigenciaSoatTaxi();
    }

    public void resumenCompraBancoTaxi() throws Exception{
        resumenCompraPage.resumenCompraBancoPago212();
    }

    //////////////////////////PAGO BANCO  RUC  ////////////////////////
    //////////////////////////////////////////////////////////////////////

    public void datosPersonalesUserRuc(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        datosPersonalesPage.datosPersonalesRUC(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );


    }


    //////////////////////////PAGO BANCO  DNI MAPFRE DOLARES  ////////////////////////
    //////////////////////////////////////////////////////////////////////

    public void datosPersonalesUserDniConMapfreDolares(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        datosPersonalesPage.datosPersonalesDniConMapfreDolares(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
        Thread.sleep(2500);
    }

    public void NumSerieVNAlfanumerico(String numserievn) throws Exception {
        numeroSeriePage.numserievnMapfreDolares();
    }


    public void muestraMapfreDolares() {
      //  formaPagoPage.isAlertPresentMapfreDolares();
        formaPagoPage.muestraMafreDolares();
    }

    public void clickBotonUtilizarMisMapfreDolares() {
        formaPagoPage.clickBotonUtilizarMisMapfreDolares();
     //   formaPagoPage.isAlertPresentMapfreDolares();
    }

    public void resumenCompraConMapfreDolares() throws Exception {
        resumenCompraPage.resumenCompraConMapfreDolares();
    }


    //////////////////////////PAGO BANCO  DNI SIN UTILIZAR MAPFRE DOLARES  ////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////

    public void ClickLinkTextNOUtilizarMisMapfreDolares() {
        formaPagoPage.clickLinkTextNOUtilizarMisMapreDolares();
    }


  //  AGREGAR CUANDO NO SE MUESTRA LA FORMA DE PAGO PORQ NO DEBE APARECER LA ALERTA

    //////////////////////////PAGO BANCO  DNI PARA MOTO   ///////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////

    public void datosPersonalesUserDniParaMoto(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        datosPersonalesPage.DatosPersonalesDNIMOTO(tipDocument,numDocument, nom, apep, apem, telf, email, departamento, provincia, distrito, direc );
    }

    public void resumenCompraParaMoto() throws Exception {
        resumenCompraPage.resumenCompraBancoPago550Moto();
    }

    //////////////////////////PAGO CON TARJETA  PARA MOTO  DNI ///////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////

    public void resumenCompraConTarjetaParaMoto() throws Exception {
        resumenCompraPage.resumenCompraConTarjeta650();
    }


    //////////////////////////  Formato de Placa Moto seleccionando Auto - CASO NO EXITOSO ///////////////////////////////////
    //////////////////////////////////////////////////////////////////////////////////////////

    public void ingresarPlacayclaseVehiculoyUsoVehiculo(String numPlaca, String claseVehiculo, String usoVehiculo) throws Exception {
        //soatHomePage.selectComboClaseVehiculo(claseVehiculo);
        soatHomePage.selectCombUsoVehiculo(claseVehiculo,usoVehiculo);
        soatHomePage.ingresarPlacaCASONOEXITOSO(numPlaca);
    }

    public void validarMensajeDeErrorFormatoDePlaca() throws Exception {
        soatHomePage.validarMensajeDeErrorFormatoDePlaca();
    }


    public void ingresoAlaPantallaDeLaTarjeta() throws Exception {
        formaPagoPage.ingresoAlaPantallaDeLaTarjeta();
    }


    public void seObtieneLaInformacionDeLaPolizaGenerada() throws Exception{
    resumenCompraPage.seObtieneLaInformacionDeLaPolizaGenerada();
    }
}
