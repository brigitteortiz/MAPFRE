package Page;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FormaPagoPage extends PageObject {

    //LOCATOR FORMA DE PAGO
    private By CardPagoTarjeta = By.xpath("//*[@id=\"divPagoTarjeta\"]/a");
    private By btnPagoTarjeta = By.xpath("//*[@id=\"validar_select\"]");
    private By CardPagoBanco = By.xpath("//*[@id=\"divPagoBanco\"]/a");
    private By btnPagoBanco = By.xpath("//*[@id=\"btnPagarBanco\"]");

    //LOCATOR PASARELA DE PAGO
    By iframe = By.xpath("//*[@id=\"iframePasarellaMapfre\"]");

    private By pasarelaIframe = By.xpath("//*[@id=\"iframePasarellaMapfre\"]");
    private By listaTarjetaIframe = By.xpath("//*[@id=\"krcardsMenu\"]");
    private By btnMenuPasarelaCards = By.xpath("//*[@id=\"krcardsMenu\"]/span[2]/i");
    private By listTipoTarjeta = By.xpath("//*[@id=\"krcards\"]/div[4]/select");
    private By TarjetaMasterCardAceptada = By.xpath("//li[@class=\"mastercard accepted card-accepted\"]");
    private By btnselectComboCard = By.xpath("/html/body/app-root/app-pago/main/div/div/div/div/div/form/app-lyra-payment/div/div/div[4]/div/div[2]/div[1]/div/div/div[2]");
    private By btnselectPasarelaCardVisa = By.xpath("/html/body/app-root/app-pago/main/div/div/div/div/div/form/app-lyra-payment/div/div/div[4]/div/div[2]/div[2]/div/ul/li[2]");
    //  private By btnPagartuSoatPasarela = By.xpath("//*[contains(text(),'Pagar ')]");

    private By btnPagartuSoatPasarela = By.xpath("//*[@class='kr-payment-button kr-visa-color']");

    //LOCATOR DE MAPFRE DOLARES
    private By textTienesMapfreDolaresDisponibles = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/div[1]/div[1]/div[1]/p");
    private By textContusMapfreDolareObtienesUnDescuento = By.xpath("//*[contains(text(),'Con tus MAPFRE Dólares obtienes un descuento de S/.66.00 que se aplicará al pago del primer año.')]");
    private By textTuSoatEsGratis = By.xpath("//*[contains(text(),'Tu SOAT es GRATIS')]");
    private By btnUtilizarMapfreDolares = By.xpath("//*[@id=\"ContentPlaceHolder1_btnMapfreDolares\"]");
    private By linkNoQuieroUtilizarMapreDolares = By.xpath("//*[contains(text(),'No quiero utilizar mis MAPFRE dólares')]");
    private By elemnt1= By.xpath("//*[@id=\"iframePasarellaMapfre\"]");
    private By element2 = By.xpath("//*[@id=\"krcardsMenu\"]");


    private BasePage basePage;
    private final WebDriver driver;
    public FormaPagoPage(WebDriver driver){
        this.driver = driver;
    }


    //VALIDAR TIPOS DE PAGO
    public void selectFormaPago() throws Exception {
        basePage.waitVisible(CardPagoTarjeta);
        try {
            if (basePage.isDisplayed(CardPagoTarjeta)) //&& basePage.isDisplayed(CardPagoBanco))
             {
                //basePage.click(CardPagoBanco);
                //basePage.isDisplayed(btnPagoBanco);
                basePage.click(CardPagoTarjeta);
                basePage.isDisplayed(btnPagoTarjeta);
                System.out.println("SUS: Seleccion de Formas de Pago: Pago con Tarjeta y Pago Banco ");
            } else {
                System.err.println("Error en la Seleccion de Forma de Pagos");
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error en la Seleccciona de Forma de Pago " + e);
            Assert.assertTrue(false);
        }
    }

    //SELECCIONAR CARD PAGO CO TARJETA
    public void pagoConTarjeta() {
        try {
            basePage.click(CardPagoTarjeta);
            System.out.println("SUS: Forma de Pago Seleccionada: PAGO CON TARJETA");
        } catch (Exception e) {
            System.err.println("Error en la Forma de Pago " + e);
            Assert.assertTrue(false);
        }
    }

    //SELECCIONAR CARD PAGO BANCO
    public void pagoBanco() {
        try {
            basePage.click(CardPagoBanco);
            System.out.println("SUS: Forma de Pago en Banco - Correcto");
        } catch (Exception e) {
            System.err.println("Error en la Forma de pago en Banco " + e);
            Assert.assertTrue(false);
        }
    }

    //SELECCIONAR BOTON PAGAR TU SOAT CON TARJETA
    public void btnPagarTuSoatFormaPago() {
        try {
            basePage.click(btnPagoTarjeta);
            System.out.println("SUS: Boton Pagar Tu Soat (Con Tarjeta) correcto");
        } catch (Exception e) {
            System.err.println("Error en el Boton Pagar Tu Soat " + e);
            Assert.assertTrue(false);
        }
    }

    //SELECCIONAR BOTON PAGAR TU SOAT EN BANCO
    public void btnPagarEnBancoFormaPago() {
        try {
            if (basePage.isDisplayed(btnPagoBanco) ){
                basePage.click(btnPagoBanco);
                System.out.println("SUS: Boton Pagar en Banco correcto");
            }else {
                System.err.println("FAIL: Error en el Boton  Continuar ");
                Assert.assertTrue(false);
            }
        } catch (Exception e) {
            System.err.println("Error en el Boton Pagar en Banco " + e);
            Assert.assertTrue(false);
        }
    }



    //SELECCIONAR EL TIPO DE TARJETA MASTERCARD y TARJETA ACEPTADA- PAGO CON TARJETA
    public void datosDeLaTarjetaMasterCardPasarelaDePago() throws Exception {
        Thread.sleep(3000);
        try {
            basePage.clicboton(pasarelaIframe,listaTarjetaIframe);
            System.out.println("Pasarela de Pagos MASTERCARD");
            //if (basePage.isDisplayed(btnMenuPasarelaCards)){
               // basePage.click(btnMenuPasarelaCards);
                basePage.selectValue(listTipoTarjeta, "MASTERCARD");
                Thread.sleep(1000);
        //    }
        if (basePage.isDisplayed(TarjetaMasterCardAceptada)){
            basePage.click(TarjetaMasterCardAceptada);
            //driver.switchTo().defaultContent();
            System.out.println("Selecciono correctamente la tarjeta");
            Thread.sleep(10000);
            Assert.assertTrue(true);
            }
            basePage.click(btnPagartuSoatPasarela);
            System.out.println("SUS: Boton Pagar en Pasarela de Pagos correcto");
            basePage.cerrarIframe();
            System.out.println("SUS: Ingreso de Datos de Tarjeta MasterCard en Pasarela de Pagos Correcto");

            Thread.sleep(50000);
            int i=0;
            while  (i <5) {
                String s=basePage.getTitle2();
                System.out.println("Valor"+i+s);
                i++;
            }
        } catch (Exception e) {
            System.err.println("Error en Datos Pasarela de Pagos " + e);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONAR BOTON PAGAR EN PASARELA DE PAGOS CORRECTO
    public void btnPagarMontoPasarela() throws Exception {
        Thread.sleep(500);
        try {

            if (basePage.isEnabled(btnPagartuSoatPasarela)){
                basePage.waitClicleable(btnPagartuSoatPasarela);
                basePage.click(btnPagartuSoatPasarela);
                //driver.switchTo().defaultContent();
                System.out.println("SUS: Boton Pagar en Pasarela de Pagos correcto");
                Thread.sleep(8000);
                Assert.assertTrue(true);

            }
            else {
                System.err.println("ERROR: EN EL BOTON PAGAR DE LA PASARELA DE PAGOS ");
                Assert.assertTrue(false);
            }
        } catch (Exception e) {
            System.err.println("Error en Boton Pagar en Pasarela de Pagos  " + e);
            Assert.assertTrue(false);
        }
    }


    //VALIDA QUE SE MUESTRE PAGO CON MAPFRE DOLARES
    public void muestraMafreDolares() {
        try {
            basePage.waitVisible(textTienesMapfreDolaresDisponibles);
            if (basePage.isDisplayed(textTienesMapfreDolaresDisponibles)){
                Assert.assertEquals("Tienes MAPFRE Dólares disponibles para usarlos como parte de pago.",
                        basePage.getText(textTienesMapfreDolaresDisponibles));
                String tienesMapfreDolaresDisponibles = basePage.getText(textTienesMapfreDolaresDisponibles);
                System.out.println("SUS: Se muestra el texto: " + tienesMapfreDolaresDisponibles + "  Correctamente");

                Assert.assertEquals("Con tus MAPFRE Dólares obtienes un descuento de S/.66.00 que se aplicará al pago del primer año.",
                        basePage.getText(textContusMapfreDolareObtienesUnDescuento));
                String conTusMapfreDolaresObtienesUnDescuento= basePage.getText(textContusMapfreDolareObtienesUnDescuento);
                System.out.println("SUS: Se muestra el texto: " + conTusMapfreDolaresObtienesUnDescuento + "  Correctamente");

                Assert.assertEquals("Tu SOAT es GRATIS",basePage.getText(textTuSoatEsGratis));
                String tusSoatEsGratis = basePage.getText(textTuSoatEsGratis);
                System.out.println("SUS: Se muestra el texto: " + tusSoatEsGratis + "  Correctamente");

                basePage.isDisplayed(btnUtilizarMapfreDolares);
                System.out.println("SUS: Se muestra el Boton: " + basePage.getText(btnUtilizarMapfreDolares) );
                basePage.isDisplayed(linkNoQuieroUtilizarMapreDolares);
                System.out.println("SUS: Se muestra el Link: " + basePage.getText(linkNoQuieroUtilizarMapreDolares) );
            }
        }catch(Exception e) {
            System.err.println("Error: No se muestra la opcion de Pago con Mapfre Dolares  " + e);
            Assert.assertTrue(false);
        }
    }

    //HACER CLIICK AL BOTON MAPFRE DOLARES
    public void clickBotonUtilizarMisMapfreDolares() {
        try {
            basePage.click(btnUtilizarMapfreDolares);
        }catch(Exception e) {
            System.err.println("Error: Al seleccionar el Boton - Utilizar Mis Mapfre Dolares " + e);
            Assert.assertTrue(false);
        }
    }

    //HACER CLIICK AL LINK TEXT NO UTILIZAR MAPFRE DOLARES
    public void clickLinkTextNOUtilizarMisMapreDolares() {
        try {
            basePage.click(linkNoQuieroUtilizarMapreDolares);
        }catch(Exception e) {
            System.err.println("Error: Al seleccionar el Link Text - No Utilizar Mis Mapfre Dolares " + e);
            Assert.assertTrue(false);
        }
    }

    //SELECCIONAR POP UP
    public void isAlertPresentMapfreDolares() {
        try {
            basePage.waitPresent();
            driver.switchTo().alert().accept();
            System.out.println("SUS: Se muestra Alerta: Se da Click en Salir (accept) ");
        }catch (Exception e){
            driver.navigate().refresh();
            System.err.println("Se realizo un Refresh  " + e);
        }
    }

    public void ingresoAlaPantallaDeLaTarjeta() throws Exception{
            basePage.clicboton(pasarelaIframe,listaTarjetaIframe);
            System.out.println("Pasarela de Pagos");

    }


}
