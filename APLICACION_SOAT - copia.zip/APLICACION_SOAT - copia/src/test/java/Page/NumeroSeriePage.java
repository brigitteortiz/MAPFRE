package Page;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Random;

public class NumeroSeriePage extends PageObject {


    // LOCATOR NUMERO SERIE VN
    private By txtVnSerie = By.xpath("//*[@id=\"ContentPlaceHolder1_txtSerie\"]");
    private By checkBoxConfirmar = By.xpath("//*[@id=\"chkConfirmar\"]");
    private By botonContinuarVin = By.xpath("//*[@id=\"ContentPlaceHolder1_btnComprar\"]");


    private   BasePage basePage;
    private final WebDriver driver;
    public NumeroSeriePage(WebDriver driver){
        this.driver = driver;
    }



    //INGRESAR EL NUMERO DE SERIE VN
    public void numserievn(String numserievn) throws Exception {
        basePage.waitVisible(txtVnSerie);
        try {
            if (basePage.isDisplayed(txtVnSerie)) {
                basePage.sendKey(txtVnSerie, numserievn);
                System.out.println("SUS: El campo VN/N° " + numserievn + " Serie es correcto");
            } else {
                System.err.println("FAIL: Error en el campo VN/N° Serie");
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error en el campo VN/N° Serie " + e);
            Assert.assertTrue(false);
        }
    }

    public void botonContinuarDespuesDeIngresarVin () throws Exception {
        basePage.waitVisible(botonContinuarVin);
        basePage.click(botonContinuarVin);
        System.out.println("SUS: Se dio click en el boton continuar");

    }


    //INGRESAR NUMER DE SERIE VN ALFANUMERICO
    public void numserievnMapfreDolares () throws Exception {
        Thread.sleep(5000);
        basePage.waitVisible(txtVnSerie);
        try {
            if (basePage.isDisplayed(txtVnSerie)) {
                String charactersnum = "0123456789";
                String characterstxt = "ABCDEFGHIJKLMNPQRSTUVWXYZ";
                String randomString = "";
                String randomNum = "";
                int lengthNum = 14;
                int lengthTxt = 3;
                Random rand = new Random();
                char[] text = new char[lengthNum];
                for (int i = 0; i < lengthNum; i++) {
                    text[i] = charactersnum.charAt(rand.nextInt(charactersnum.length()));
                }
                for (int i = 0; i < lengthNum; i++) {
                    randomNum += text[i];
                }
//
                char[] text1 = new char[lengthTxt];
                for (int i = 0; i < lengthTxt; i++) {
                    text1[i] = characterstxt.charAt(rand.nextInt(characterstxt.length()));
                }
                for (int i = 0; i < lengthTxt; i++) {
                    randomString += text1[i];
                }
                String RandTotal = randomString + randomNum;
                basePage.sendKey(txtVnSerie, RandTotal);
                System.out.println("SUS: El campo VN/N° " + RandTotal + " Serie es correcto");
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error en el campo VN/N° Serie Mapfre Dolares" + e);
            Assert.assertTrue(false);
        }
    }



    //APARECE EL CHECK BOX AL INGRESAR
    public void checkBox() throws Exception {
       // basePage.waitVisible(txtVnSerie);
        try {
            if (basePage.isDisplayed(checkBoxConfirmar)) {
       //         basePage.waitVisible(checkBoxConfirmar);
                basePage.click(checkBoxConfirmar);
                System.out.println("SUS: Se selecciono el CheckBox  correcto");
            } else {
                System.err.println("FAIL: Error en la Seleccion de ChecbBox");
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error en el campo VN/N° Serie " + e);
            Assert.assertTrue(false);
        }
    }

    //SELECCIONAR POP UP
    public void isAlertPresent() {
        try {
            basePage.waitPresent();
            driver.switchTo().alert().accept();
            System.out.println("SUS: Se muestra Alerta: Se da Click en Salir (accept) ");
        }catch (Exception e){
            driver.navigate().refresh();
            System.err.println("FAIL: ERROR al Seleccionar la Alerta Pagina VN  " + e);
        }
    }

}
