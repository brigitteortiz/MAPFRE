package Page;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DatosVehiculoPage extends PageObject {


    // LOCATOR DATOS VEHICULO
    private By listMarca = By.xpath("//*[@id='ContentPlaceHolder1_ddlMarca']");
    private By listModelo = By.xpath("//*[@id='ContentPlaceHolder1_ddlModelo']");
    private By txtYearFabr = By.xpath("//*[@id='ContentPlaceHolder1_txtAnho']");
    private By listClase = By.xpath("//*[@id='ContentPlaceHolder1_ddlCategoria']");
    private By listNumAsientos = By.xpath("//*[@id='ContentPlaceHolder1_ddlNumAsientos']");
    private By listUsoVehiculo = By.xpath("//*[@id='ContentPlaceHolder1_ddlUso']");
    //private By btnMejorPrecio = By.xpath("//*[@id='ContentPlaceHolder1_btnComprar'  or @type='submit']");
    private By btnMejorPrecio = By.xpath("//*[@id='ContentPlaceHolder1_btnComprar']");

    private WebDriver driver;
    private BasePage basePage;
    public DatosVehiculoPage(WebDriver driver) {
        this.driver = driver;
    }

    //INGRESAR DATOS DEL VEHICULO
    public void datosVehiculo(String marca, String modelo, String clase, String yearFabric, String numAsientos, String usoVehiculo) throws Exception{
        Thread.sleep(9000);
        try {

            //basePage.waitVisible(listMarca);
            basePage.selectValue(listMarca,marca);
            System.out.println("SUS: Se selecciono Marca: " + marca );
            Thread.sleep(1000);
            basePage.selectValue(listModelo, modelo);
            System.out.println("SUS: Se selecciono Modelo: " + modelo );
            Thread.sleep(1000);
            basePage.sendKey(txtYearFabr,yearFabric);
            System.out.println("SUS: Se selecciono año de fabrica: " + yearFabric );
            Thread.sleep(2000);
            basePage.waitVisible(listClase);
            basePage.selectValue(listClase, clase);
            System.out.println("SUS: Se selecciono clase de vehiculo: " + clase );
            Thread.sleep(4000);
            basePage.waitVisible(listNumAsientos);
            basePage.selectValue(listNumAsientos, numAsientos);
            System.out.println("SUS: Se selecciono numero de asientos: " + numAsientos );
            Thread.sleep(2000);
            basePage.waitVisible(listUsoVehiculo);
            basePage.selectValue(listUsoVehiculo, usoVehiculo);
            System.out.println("SUS: Se selecciono uso de vehiculo: " + usoVehiculo );
            Thread.sleep(2000);

            if (!clase.equals("MOTOCICLETA")){
                basePage.selectValue(listUsoVehiculo, "Particular");
                basePage.selectValue(listUsoVehiculo, "Otros");
                basePage.selectValue(listUsoVehiculo, "Taxi");
                basePage.selectValue(listUsoVehiculo, usoVehiculo);
                System.out.println("SUS: Los Datos del Vehiculo son Correcto");
            } else {
                basePage.selectValue(listUsoVehiculo, "Particular");
                basePage.selectValue(listUsoVehiculo, "Comercial");
                basePage.selectValue(listUsoVehiculo, usoVehiculo);
                System.out.println("SUS: Los Datos del Vehiculo son Correcto");
            }
        }catch (Exception e){
            System.err.println("FAIL: Error Los Datos del Vihiculo" + e);
            Assert.assertTrue(false);
        }
    }


    //INGRESAR DATOS DEL VEHICULO TOYOTA - YARIS
    public void datosVehiculoToyota(String yearFabric) {
        try {
            basePage.waitVisible(listMarca);
            basePage.selectValue(listMarca,"TOYOTA");
            basePage.selectValue(listModelo, "YARIS");
            basePage.sendKey(txtYearFabr,yearFabric);
            basePage.selectValue(listClase, "AUTOMOVIL");
            basePage.selectValue(listNumAsientos, "5");
            basePage.selectValue(listUsoVehiculo, "Otros");
            basePage.selectValue(listUsoVehiculo, "Particular");
            basePage.selectValue(listUsoVehiculo, "Taxi");
            System.out.println("SUS: Los Datos del Vihiculo son Correcto");

        }catch (Exception e){
            System.err.println("FAIL: Error Los Datos del Vihiculo" + e);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONAR EL BOTON VER MEJOR PRECIO
    public void obtenElMejorPrecio() {
        try {
            basePage.click(btnMejorPrecio);
            System.out.println("SUS: El boton: Obtener el mejor precio (Datos Del Vehiculo) es Correcto ");
        }catch (Exception e){
            System.err.println("Error El boton Obtener el mejor precio (Datos Del Vehiculo)  " + e);
            Assert.assertTrue(false);
        }
    }

}
