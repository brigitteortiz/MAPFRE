package Page;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Random;
public class DatosPersonalesPage extends PageObject {
    // LOCATOR DATOS PESONALES
    private By listTipDocumento = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlTipDocumento\"]");
    private By txtNumDocumento = By.xpath("//*[@id=\"ContentPlaceHolder1_txtNumDocumento\"]");
    private By listNacionalidad = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlPais\"]");
    private By txtNomNuevo = By.xpath("//*[@id=\"atm-txtNombresNuevo\"]");
    private By txtNombres = By.xpath("//*[@id=\"ContentPlaceHolder1_txtNombres\"]");
    private By txtApePat = By.xpath("//*[@id=\"ContentPlaceHolder1_txtApePaterno\"]");
    private By txtApeMat = By.xpath("//*[@id=\"ContentPlaceHolder1_txtApeMaterno\"]");
    private By txtTelf = By.xpath("//*[@id=\"ContentPlaceHolder1_txtTelefono\"]");
    private By txtEmail = By.xpath("//*[@id=\"ContentPlaceHolder1_txtEmail\"]");
    private By txtDir = By.xpath("//*[@id=\"ContentPlaceHolder1_txtDireccion\"]");
    private By listDepartamento = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlDepartamento\"]");
    private By listProvincia = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlProvincia\"]");
    private By listDistrito = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlDistrito\"]");

    private By btnContinuarDatosPersonales = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/div[1]/ul/li[13]/div");
    private By btnContinuarConDatosRegistradosEnBD = By.xpath("//*[@id=\"UpdatePanel1\"]/section/div[1]/div[1]/ul/li[15]/div/input[1]");


    private WebDriver driver;
    private BasePage basePage;
    public DatosPersonalesPage(WebDriver driver) {
        this.driver = driver;
    }

    // INGRESAR DATOS PERSONALES CON DNI (EN TABLA DE DATOS) DNI REGISTRADO EN LA BASE DE DATOS  SOAT
    public void DatosPersonalesDNI(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        basePage.waitVisible(txtNumDocumento);
        basePage.selectValue(listTipDocumento, "DNI");
        basePage.selectValue(listTipDocumento, "CEX");
        basePage.selectValue(listTipDocumento, "RUC");
        basePage.selectValue(listTipDocumento, tipDocument);
        System.out.println("TIPO DE DOCUMENETO SELECCIONADO  " + tipDocument);

        basePage.click(txtNumDocumento);
        basePage.sendKey(txtNumDocumento,numDocument);
        basePage.sendKeyTab(txtNumDocumento);
        Thread.sleep(2000);
        basePage.waitVisible(txtTelf);
        basePage.getText(txtNomNuevo);

        if (basePage.isDisplayed(txtTelf)) {
            basePage.waitVisible(txtTelf);
            basePage.waitClicleable(txtTelf);
            basePage.sendKey(txtTelf,telf);
            basePage.sendKey(txtEmail,email);
            basePage.selectValue(listDepartamento, departamento);
            basePage.selectValue(listProvincia, provincia);
            basePage.selectValue(listDistrito, distrito);
            basePage.sendKey(txtDir,direc);
            System.out.println("SUS: El DNI " + numDocument +" ya se encuentra registrado en nuestra BD, se agregaron los datos faltantes Correctamente: "
                    + telf + " "+ email+ " " + departamento+ " " +  provincia+ " " +  distrito) ;
            Assert.assertTrue(true);
        } else  {
            System.err.println("FAIL: Error en los Datos Personales del DNI " + numDocument);
            Assert.assertTrue(false);
        }
    }


    //INGRESAR DATOS PERSONALES CON CARNET DE EXTRANJERIA (CEX ALEATORIO)
    public void DatosPersonalesCEX(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        Thread.sleep(5000);
        basePage.isDisplayed(txtNumDocumento);
      //  try {
            basePage.selectValue(listTipDocumento, "DNI");
            basePage.selectValue(listTipDocumento, "CEX");
            basePage.selectValue(listTipDocumento, "RUC");
            basePage.selectValue(listTipDocumento, tipDocument);
            System.out.println("TIPO DE DOCUMENETO SELECCIONADO  " + tipDocument);

               String characters = "0123456789";
               String randomString = "";
               int length = 12;
               Random rand = new Random();
               char[] text = new char[length];
               for (int i = 0; i < length; i++) {
                   text[i] = characters.charAt(rand.nextInt(characters.length()));
               }
               for (int i = 0; i < length; i++) {
                   randomString += text[i];
               }
               basePage.click(txtNumDocumento);
               basePage.sendKey(txtNumDocumento, randomString);
               basePage.sendKeyTab(txtNumDocumento);
              System.out.println("NUMERO DE CEX INGRESADO " + randomString);
               Thread.sleep(2500);
               basePage.waitVisible(txtNombres);
               basePage.selectValue(listNacionalidad, "ESPANA");
               System.out.println("SUS: Combo Box Nacionalidad CEX Correcto");

               if (basePage.isDisplayed(txtNombres)) {
                   basePage.sendKey(txtNombres, nom);
                   basePage.sendKey(txtApePat, apep);
                   basePage.sendKey(txtApeMat, apem);
                   basePage.sendKey(txtTelf, telf);
                   basePage.sendKey(txtEmail, email);
                   basePage.selectValue(listDepartamento, departamento);
                   basePage.selectValue(listProvincia, provincia);
                   basePage.selectValue(listDistrito, distrito);
                   basePage.sendKey(txtDir, direc);
                   System.out.println("SUS: Se agrego el Documento " + tipDocument + " - " + numDocument + " - " + randomString + " de Extranejeria: Correctamente");
                   Assert.assertTrue(true);
               } else {
                   System.err.println("FAIL: Error en los Datos Personales del Carnet de Extranjeria (CEX) " + numDocument);
                   Assert.assertTrue(false);
               }
           }



    //INGRESAR DATOS PERSONALES CON RUC 10 (TABLA DE DATOS)
    public void datosPersonalesRUC(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        basePage.waitVisible(txtNumDocumento);
        basePage.selectValue(listTipDocumento, "DNI");
        basePage.selectValue(listTipDocumento, "RUC");
        basePage.selectValue(listTipDocumento, "CEX");
        basePage.selectValue(listTipDocumento, tipDocument);
        System.out.println("TIPO DE DOCUMENETO SELECCIONADO  " + tipDocument);

        basePage.click(txtNumDocumento);
        basePage.sendKey(txtNumDocumento,numDocument);
        basePage.sendKeyTab(txtNumDocumento);
          basePage.waitClicleable(txtNombres);
        if (basePage.isDisplayed(txtNombres)) {
            basePage.sendKey(txtNombres,nom);
            basePage.sendKey(txtApePat,apep);
            basePage.sendKey(txtApeMat,apem);
            basePage.sendKey(txtTelf,telf);
            basePage.sendKey(txtEmail,email);
            basePage.selectValue(listDepartamento, departamento);
            basePage.selectValue(listProvincia, provincia);
            basePage.selectValue(listDistrito, distrito);
            basePage.sendKey(txtDir,direc);
            System.out.println("SUS: Se agrego el Documento " + tipDocument + " - "+ numDocument + "- "+ email + " se agrego Correctamente");
            Assert.assertTrue(true);
        } else  {
            System.err.println("FAIL: Error en los datos Personales del RUC " + numDocument);
            Assert.assertTrue(false);
        }
    }


    //INGRESAR DATOS PERSONALES CON DNI QUE TIENE MAPFRE DOLARES(TABLA DE DATOS)
    public void datosPersonalesDniConMapfreDolares(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        basePage.waitVisible(txtNumDocumento);
        basePage.selectValue(listTipDocumento, "DNI");
        basePage.selectValue(listTipDocumento, "CEX");
        basePage.selectValue(listTipDocumento, "RUC");
        basePage.selectValue(listTipDocumento, tipDocument);
        System.out.println("TIPO DE DOCUMENTO SELECCIONADO  " + tipDocument);

        basePage.click(txtNumDocumento);
        basePage.sendKey(txtNumDocumento,numDocument);
        basePage.sendKeyTab(txtNumDocumento);
        Thread.sleep(2000);
        basePage.waitVisible(txtTelf);
        basePage.getText(txtNomNuevo);

        if (basePage.isDisplayed(txtTelf)) {
            basePage.waitVisible(txtTelf);
            basePage.waitClicleable(txtTelf);
            basePage.sendKey(txtTelf,telf);
            basePage.sendKey(txtEmail,email);
            basePage.selectValue(listDepartamento, departamento);
            Thread.sleep(2000);
            basePage.selectValue(listProvincia, provincia);
            Thread.sleep(2000);
            basePage.selectValue(listDistrito, distrito);
            Thread.sleep(2000);
            basePage.sendKey(txtDir,direc);
            System.out.println("SUS: El DNI " + numDocument +" ya se encuentra registrado en nuestra BD, se agregaron los datos faltantes Correctamente: "
                    + telf + " "+ email+ " " + departamento+ " " +  provincia+ " " +  distrito) ;
            Assert.assertTrue(true);
        } else  {
            System.err.println("FAIL: Error en los Datos Personales del DNI " + numDocument);
            Assert.assertTrue(false);
        }
    }

    // INGRESAR DATOS PERSONALES CON DNI PARA MOTOS (EN TABLA DE DATOS) DNI REGISTRADO EN LA BASE DE DATOS  SOAT
    public void DatosPersonalesDNIMOTO(String tipDocument, String numDocument, String nom, String apep, String apem, String telf, String email, String departamento, String provincia, String distrito, String direc) throws Exception {
        basePage.waitVisible(txtNumDocumento);
        basePage.selectValue(listTipDocumento, "DNI");
        basePage.selectValue(listTipDocumento, "CEX");
        basePage.selectValue(listTipDocumento, "RUC");
        basePage.selectValue(listTipDocumento, tipDocument);
        System.out.println("TIPO DE DOCUMENTO SELECCIONADO  " + tipDocument);

        basePage.click(txtNumDocumento);
        basePage.sendKey(txtNumDocumento,numDocument);
        basePage.sendKeyTab(txtNumDocumento);
        Thread.sleep(2000);
        basePage.waitVisible(txtTelf);
        basePage.getText(txtNomNuevo);

        if (basePage.isDisplayed(txtTelf)) {
            basePage.waitVisible(txtTelf);
            basePage.waitClicleable(txtTelf);
            Thread.sleep(2000);
            basePage.sendKey(txtTelf,telf);
            Thread.sleep(2000);
            basePage.sendKey(txtEmail,email);
            Thread.sleep(2000);
            basePage.selectValue(listDepartamento, departamento);
            Thread.sleep(2000);
            basePage.selectValue(listProvincia, provincia);
            Thread.sleep(2000);
            basePage.selectValue(listDistrito, distrito);
            Thread.sleep(2000);
            basePage.sendKey(txtDir,direc);
            System.out.println("SUS: El DNI " + numDocument +" ya se encuentra registrado en nuestra BD, se agregaron los datos faltantes Correctamente: "
                    + telf + " "+ email+ " " + departamento+ " " +  provincia+ " " +  distrito) ;
            Assert.assertTrue(true);
        } else  {
            System.err.println("FAIL: Error en los Datos Personales del DNI " + numDocument);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONAR BOTON CONTINUAR EN EL INGRESO DE DATOS PERSONALES
    public void botonContinuarDeIngresarDatosPersonales() throws Exception{
        Thread.sleep(500);
        try {
            if (basePage.isDisplayed(btnContinuarDatosPersonales) ){
                basePage.click(btnContinuarDatosPersonales);
                System.out.println("SUS: Boton Continuar Correcto");
            }else {
                System.err.println("FAIL: Error en el Boton  Continuar ");
                Assert.assertTrue(false);
            }
        }catch (Exception e) {
            System.err.println("FAIL: Error en Datos Personales " + e);
            Assert.assertTrue(false);
        }
    }

    public void btnContinuarConDatosRegistradosEnBD() {
        try {
            if (basePage.isDisplayed(btnContinuarConDatosRegistradosEnBD) ){
                basePage.click(btnContinuarConDatosRegistradosEnBD);
                System.out.println("SUS: Boton Continuar Correcto");
            }else {
                System.err.println("FAIL: Error en el Boton  Continuar ");
                Assert.assertTrue(false);
            }
        }catch (Exception e) {
            System.err.println("FAIL: Error en Datos Personales " + e);
            Assert.assertTrue(false);
        }
    }
}