package Page;

//import cucumber.api.java.eo.Se;

import net.serenitybdd.core.pages.PageObject;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import java.util.Random;
import java.util.Set;

public class SoatHomePage extends PageObject {

    private BasePage basePage;
    private final WebDriver driver;
    //URLPREVAL IMG
    private By imgMapfre = By.xpath("//img[@src='../img/logo-mapfre.png']");
    //LOCATOR HOME    //html/body/div[4]/div[2]/iframe
    private By iframeHome = By.xpath("//html/body/div[3]/div[2]/iframe");    //html/body/div[3]/div[2]/iframe
    private By textProxy = By.xpath("//html/body");
    private  By txtNumPlaca = By.xpath("//input[@id='ContentPlaceHolder1_txtNumPlaca']");
    private  By checkboxProctDat = By.xpath("//*[@id=\"ContentPlaceHolder1_chkTerminos\"]");
    private  By textClausulaProteccionDatosPersonales = By.xpath("//*[contains(text(),'Cláusula de consentimiento de tratamiento de datos personales')]");
    private  By textParrafoProteccionDatosPersonales = By.xpath("//*[@id=\"post-343256\"]/div/div/div/div[3]/div[2]/div/div/div/p[1]");
    private  By btnVerPrecio = By.xpath("//*[@value=\"Ver precio\" or @id=\"ContentPlaceHolder1_btnComprar\"]");
    private  By logoMapfre = By.xpath("//*[@id=\"logo_mapfre\"]/img");
    private  By homepage = By.xpath("//*[@id=\"UpdatePanel1\"]/div");
    private  By listClaseVehiculo = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlClase\"]");
    private  By listUsoVehiculo = By.xpath("//*[@id=\"ContentPlaceHolder1_ddlUso\"]");
    //private  By TextErrorFormatoPlaca = By.xpath("//*[@id='ContentPlaceHolder1_ltContenido']");
    private By MensajeDeFormatoDePlaca = By.cssSelector("body > div.modal");
    private By TextErrorFormatoPlaca = By.cssSelector("body > div.modal > h2");
    //private By TextErrorFormatoPlaca = By.xpath("/html/body/div[4]/h2");
    private By SeleccionarMoto = By.xpath("//*[@id=\"ContentPlaceHolder1_divFormularioTipo\"]/div[2]/label/i");


    public SoatHomePage(WebDriver driver){
        this.driver = driver;
    }
    //INGRESAR A LA URL PRE-PROD SOAT
    public void UrlPre() throws Exception {
        basePage.UrlPreProd();
    }

    //VALIDAR EL HOME PAGE DE SOAT Y CAPCHA - HOME PAGE
    public void UrlPreVal() throws Exception {
        Thread.sleep(5000);
        try {
            if (basePage.isDisplayed(iframeHome)) {
                System.out.println("SUS: La Aplicacion Soat cargo, evadiendo el Capcha  correctamente");
                basePage.sendKeyScape(iframeHome);
                Assert.assertTrue(true);
            } else if (basePage.isDisplayed(txtNumPlaca)) {
                System.out.println("SUS: La Aplicacion Soat cargo correctamente");
                Assert.assertTrue(true);
            }
            else {
                basePage.UrlPreProd();
                if (basePage.isDisplayed(iframeHome)) {
                    System.out.println("SUS: La Aplicacion Soat cargo, evadiendo el Capcha  correctamente");
                    basePage.sendKeyScape(iframeHome);
                    Assert.assertTrue(true);
                } else if (basePage.isDisplayed(txtNumPlaca)) {
                    System.out.println("SUS: La Aplicacion Soat cargo correctamente");
                    Assert.assertTrue(true);
                }
            }
        }catch(Exception e){
            System.out.println("Error en la Carga de la Aplicacion Soat PreProd");
            Assert.assertTrue(false);
        }
    }

    //SELECCIONA CLASE  DE VEHICULO - PARTICULAR - COMBO BOX - HOME PAGE
    public void selectComboClaseVehiculo(String claseVehiculo) {
        try {
            if (basePage.isEnabled(listClaseVehiculo)) {
                basePage.selectValue(listClaseVehiculo,"Autos, camionetas, pickups");
                Thread.sleep(500);
                basePage.selectValue(listClaseVehiculo, "Motos");
                Thread.sleep(500);
                basePage.selectValue(listClaseVehiculo,claseVehiculo);
                Thread.sleep(1000);
                System.out.println("SUS: Combo Box - Clase  de Vehiculo Correcto: " + claseVehiculo);
            } else {
                System.err.println("Error en el Combo Box - Clase  de Vehiculo "+ claseVehiculo);
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error en el Combo Box - Clase  de Vehiculo " + e);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONA USO DE VEHICULO Y MOTO - COMBO BOX - HOME PAGE
    public void selectCombUsoVehiculo(String claseVehiculo, String usoVehiculo) throws Exception {
        try {
            if (claseVehiculo.equals("Autos, camionetas, pickups")) {
                if (basePage.isEnabled(listUsoVehiculo)) {
                    basePage.selectValue(listUsoVehiculo, "Particular");
                    Thread.sleep(500);
                    basePage.selectValue(listUsoVehiculo, "Carga");
                    Thread.sleep(500);
                    basePage.selectValue(listUsoVehiculo, "Taxi");
                    Thread.sleep(500);
                    basePage.selectValue(listUsoVehiculo, "Otros");
                    Thread.sleep(500);
                    basePage.selectValue(listUsoVehiculo, usoVehiculo);
                    System.out.println("SUS: Combo Box - Uso de Vehiculo Correcto: " + usoVehiculo);
                }
                else {
                    System.err.println("Error en el Combo Box - Uso de Vehiculo " + usoVehiculo);
                }
            }
            else if (claseVehiculo.equals("Motos")){
                basePage.click(SeleccionarMoto);
                System.out.println("Se selecciono la opcion MOTO");
                if (basePage.isEnabled(listUsoVehiculo)) {
                    basePage.selectValue(listUsoVehiculo,"Comercial");
                    Thread.sleep(500);
                    basePage.selectValue(listUsoVehiculo,"Particular");
                    Thread.sleep(500);
                    basePage.selectValue(listUsoVehiculo,usoVehiculo);
                    System.out.println("SUS: Combo Box - Uso de Vehiculo Correcto: " + usoVehiculo);
                } else {
                    System.err.println("Error en el Combo Box - Uso de Vehiculo: " + usoVehiculo);
                }
            }
            else {
                System.err.println("Error en el Combo Box - Uso de Vehiculo ");
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error en el Combo Box - Uso de Vehiculo " + e);
            Assert.assertTrue(false);
        }
    }


    //INGRESAR NUMERO DE PLACA ALEATORIA - HOME PAGE
    public void ingresarPlaca(String claseVehiculo) throws InterruptedException {
        try {
            if (claseVehiculo.equals("Autos, camionetas, pickups")) {
                if (basePage.isEnabled(txtNumPlaca)) {
                    basePage.click(txtNumPlaca);
                    basePage.clear(txtNumPlaca);
                    String charactersnum = "123456789";
                    String characterstxt = "ABCDEFGHIJKLMNPQRSTUVWXYZ";
                    String randomString = "";
                    String randomNum = "";
                    int lengthNum = 3;
                    int lengthTxt = 3;
                    Random rand = new Random();
                    char[] text = new char[lengthNum];
                    for (int i = 0; i < lengthNum; i++) {
                        text[i] = charactersnum.charAt(rand.nextInt(charactersnum.length()));
                    }
                    for (int i = 0; i < lengthNum; i++) {
                        randomNum += text[i];
                    }
//
                    char[] text1 = new char[lengthTxt];
                    for (int i = 0; i < lengthTxt; i++) {
                        text1[i] = characterstxt.charAt(rand.nextInt(characterstxt.length()));
                    }
                    for (int i = 0; i < lengthTxt; i++) {
                        randomString += text1[i];
                    }
                    String RandTotal = randomString + randomNum;
                    basePage.sendKey(txtNumPlaca, RandTotal);
                    System.out.println("SUS: Ingreso de Numero de Placa correcto: " + RandTotal);
                } else {
                    System.err.println("Error a ingressar el Numero de Placa");
                }
            }

            else if (claseVehiculo.equals("Motos")){
                if (basePage.isEnabled(txtNumPlaca)) {
                    basePage.click(txtNumPlaca);
                    basePage.clear(txtNumPlaca);
                    String charactersnum = "123456789";
                    String characterstxt = "ABCDF";
                    String randomString = "";
                    String randomNum = "";
                    int lengthNum = 4;
                    int lengthTxt = 2;
                    Random rand = new Random();
                    char[] text = new char[lengthNum];
                    for (int i = 0; i < lengthNum; i++) {
                        text[i] = charactersnum.charAt(rand.nextInt(charactersnum.length()));
                    }
                    for (int i = 0; i < lengthNum; i++) {
                        randomNum += text[i];
                    }
//
                    char[] text1 = new char[lengthTxt];
                    for (int i = 0; i < lengthTxt; i++) {
                        text1[i] = characterstxt.charAt(rand.nextInt(characterstxt.length()));
                    }
                    for (int i = 0; i < lengthTxt; i++) {
                        randomString += text1[i];
                    }
                    String RandTotal = randomString + randomNum;
                    basePage.sendKey(txtNumPlaca, RandTotal);
                    System.out.println("SUS: Ingreso de Numero de Placa correcto: " + RandTotal);

                } else {
                    System.err.println("Error a ingressar el Numero de Placa");
                }
            }
            else {
                System.out.println("Error al Ingresar el Numero de Placa");
            }
        } catch (Exception e) {
            System.err.println("FAIL: Error al Ingresar el Numero de Placa " + e);
            Assert.assertTrue(false);
        }
    }


    //SELECCIONAR CHECK BOX - HOME PAGE
    public void seleccionarCheckBox() {
        try {

            basePage.click(checkboxProctDat);
            //basePage.click(By.id("lblText")); //Clausula de Proteccion de Datos

            //ChangeWindowsTab();
            System.out.println("SUS: Check Box seleccionado Correctamente");

        } catch (Exception e) {
            System.err.println("FAIL: Error con el checckBox");
        }
    }


    public void ChangeWindowsTab () throws Exception {
        String mainTab = driver.getWindowHandle();
        String newTab = "";
        Set<String> handles = driver.getWindowHandles();

        for (String actual : handles){
            if (!actual.equalsIgnoreCase(mainTab)){
                System.out.println("--Changing  Tab ");
                driver.switchTo().window(actual);
                newTab = actual;
            }
        }
        int TextoParrafoProteccionDatosPersonales = basePage.getText(textParrafoProteccionDatosPersonales).length();
        if (TextoParrafoProteccionDatosPersonales > 0){
            Assert.assertEquals("Cláusula de consentimiento de tratamiento de datos personales",
                    basePage.getText(textClausulaProteccionDatosPersonales));
            System.out.println("SUS: La Clausula de Proteccion De Datos es Correcto");
        }
        else {
            System.err.println("FAIL: ERROR en La Clausula de Proteccion De Datos");
        }
        driver.close();
        driver.switchTo().window(mainTab);
    }


    //SELECCIONAR BOTON VER PRECIO DEL HOME PAGE
    public void verPrecio() throws Exception {
        try {
            basePage.click(btnVerPrecio);
            System.out.println("SUS: Boton Ver Precio seleccionado Correctamente");

        } catch (Exception e) {
            System.err.println("FAIL: Error con Boton Ver Precio" + e);
        }
    }


    // INGRESAR NUMERO DE PLACA CON FORMATO DE MOTO SELECCIONANDO AUTO - CASO NO EXITOSO
    public void ingresarPlacaCASONOEXITOSO(String numPlaca) throws Exception {
        try {
            basePage.click(txtNumPlaca);
            basePage.clear(txtNumPlaca);
            basePage.sendKey(txtNumPlaca,numPlaca);
        }catch (Exception e) {
            System.err.println("FAIL: Error con Boton Ver Precio" + e);
        }
    }

    // VALIDAR MENSAJE DE ERROR POR FORMATO DE PLACA DIFERENTES - CASO NO EXITOSO
    public void validarMensajeDeErrorFormatoDePlaca() throws Exception {
        Thread.sleep(500);
        try {
            basePage.waitVisible(MensajeDeFormatoDePlaca);
            String TextErrorFormatPlaca = basePage.getText(TextErrorFormatoPlaca);
            if (basePage.isDisplayed(TextErrorFormatoPlaca)){
                Assert.assertEquals("Ingresa un formato de placa válido",
                        basePage.getText(TextErrorFormatoPlaca));
                System.out.println("SUS: Se muestra el mensaje de Error: " + TextErrorFormatPlaca);
            }else {
                System.err.println("FAIL: ERROR, no se muestra el mensaje de Error ");
            }
        }catch (Exception e) {
            System.err.println("FAIL: Error en validar el mensaje de error" + e);
        }

    }
}


